<?php
/*-----------------------------------------------------------------------------------*/
/* MEGA MENU
/*-----------------------------------------------------------------------------------*/
function bolder_post_type_megamenu() {

    $labels = array(
        'name' => __( 'Mega Menu', 'bolder' ),
        'singular_name' => __( 'Mega Menu Item', 'bolder' ),
        'add_new' => __( 'Add New', 'bolder' ),
        'add_new_item' => __( 'Add New Menu Item', 'bolder' ),
        'edit_item' => __( 'Edit Menu Item', 'bolder' ),
        'new_item' => __( 'New Menu Item', 'bolder' ),
        'view_item' => __( 'View Menu Item', 'bolder' ),
        'search_items' => __( 'Search Menu Items', 'bolder' ),
        'not_found' => __( 'No Menu Items found', 'bolder' ),
        'not_found_in_trash' => __( 'No Menu Items found in Trash', 'bolder' ),
        'parent_item_colon' => __( 'Parent Menu Item:', 'bolder' ),
        'menu_name' => __( 'Mega Menu', 'bolder' ),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'description' => __('Mega Menus.', 'bolder'),
        'supports' => array( 'title', 'editor' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 40,
        'show_in_nav_menus' => true,
        'publicly_queryable' => false,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => false,
        'capability_type' => 'post'
    );

    register_post_type( 'megamenu', $args );
}
add_action( 'init', 'bolder_post_type_megamenu' );

?>