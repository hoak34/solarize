<?php
	include_once dirname(__FILE__).'/post-feature.php';
	include_once dirname(__FILE__).'/post-megamenu.php';
	include_once dirname(__FILE__).'/post-portfolio.php';
	include_once dirname(__FILE__).'/post-service.php';
	include_once dirname(__FILE__).'/post-testimonial.php';
?>
