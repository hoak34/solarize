<?php 

	if ( !function_exists('bolder_service_post_type') ) {

		/*======== Register post type ========*/
		function bolder_service_post_type()
		{
		    $labels = array(
		        'name' => __('Service', 'post type general name', 'bolder'),
		        'singular_name' => __('Service', 'post type singular name', 'bolder'),
		        'add_new' => __('Add New', 'service', 'bolder'),
		        'all_items' => __('All Services', 'bolder'),
		        'add_new_item' => __('Add New Service', 'bolder'),
		        'edit_item' => __('Edit Service', 'bolder'),
		        'new_item' => __('New Service', 'bolder'),
		        'view_item' => __('View Service', 'bolder'),
		        'search_items' => __('Search Service', 'bolder'),
		        'not_found' =>  __('No Service Found', 'bolder'),
		        'not_found_in_trash' => __('No Service Found in Trash', 'bolder'),
		        'parent_item_colon' => ''
		    );

		    $args = array(
		        'labels' => $labels,
		        'public' => true,
		        'show_ui' => true,
		        'capability_type' => 'post',
		        'hierarchical' => false,
		        'rewrite' => array('slug' => 'service-view', 'with_front' => true),
		        'query_var' => true,
		        'show_in_nav_menus'=> false,
		        'supports' => array('title', 'thumbnail', 'excerpt', 'editor'),
            	'menu_icon' 		=> 'dashicons-star-filled',
		    );
		    add_theme_support( 'post-thumbnails' );
		    register_post_type( 'service' , $args );
		}
		add_action('init', 'bolder_service_post_type');

	}

?>