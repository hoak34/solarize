<?php
function vc_bolder_tta_container_classes($classes, $atts){
	if($atts['style'] == 'bolder'){
		$classes[] = 'bolder-style';
	}

	return $classes;
}
add_action( 'init', 'vc_bolder_icons', 9999);
function vc_bolder_icons(){

	//get title and style params
	$title_and_style_params = (array)vc_map_integrate_shortcode( 'vc_tta_tour', '', '',
		array(
			// we need only type, icon_fontawesome, icon_.., NOT color and etc
			//'include_only_regex' => '/^(type|icon_\w*)/'
			'include_only' => array('title', 'style')
		),false
	);
	//append bolder_style to style value
	if(isset($title_and_style_params[1])){
		$title_and_style_params[1]['value'][__( 'Bolder style', 'js_composer' )] = 'bolder';
	}

	//get depend params
	$depend_params = (array)vc_map_integrate_shortcode( 'vc_tta_tour', '', '',
		array(
			// we need only type, icon_fontawesome, icon_.., NOT color and etc
			//'include_only_regex' => '/^(type|icon_\w*)/'
			'exclude' => array('title','style','el_class','css_editor')
		),array(
			'element' => 'style',
			'value' => array('classic', 'modern', 'flat', 'outline')
		)
	);

	$el_class_and_css_editor_params = (array)vc_map_integrate_shortcode( 'vc_tta_tour', '', '',
		array(
			// we need only type, icon_fontawesome, icon_.., NOT color and etc
			//'include_only_regex' => '/^(type|icon_\w*)/'
			'include_only' => array('el_class', 'css_editor')
		),false
	);

	$params = array_merge(
		$title_and_style_params,
		$depend_params,
		$el_class_and_css_editor_params
	);
	vc_add_params( 'vc_tta_tour', $params );


	//add  bolder class to tta container
	add_filter( 'vc_tta_container_classes', 'vc_bolder_tta_container_classes' , 10, 2);

	// add sub title for section element
	$attributes = array(
		'type' => 'textfield',
		'param_name' => 'sub_title',
		'heading' => __( 'Sub Title', 'js_composer' ),
		'description' => __( 'Enter section sub title (Note: you can leave it empty).', 'js_composer' ),
		'weight' => 1,
	);
	vc_add_param( 'vc_tta_section', $attributes );

	/*add_action('vc_enqueue_font_icon_element', 'bolder_vc_icon_element_fonts_enqueue');
	function bolder_vc_icon_element_fonts_enqueue($font)
	{
		switch ($font) {
			case 'themeify':
				wp_enqueue_style('themeify-icons', get_template_directory_uri().'/assets/css/themify-icons.css');
				break;
		}
	}*/
	// SEE HOOKS FOLDER FOR FONTS REGISTERING/ENQUEUE IN BASE @path "/include/autoload/hook-vc-iconpicker-param.php"
	//replace openiconic icon by themeify icon
	add_filter( 'vc_iconpicker-type-openiconic', 'vc_iconpicker_type_themeify' );

	/**
	 * Fontawesome icons from FontAwesome :)
	 *
	 * @param $icons - taken from filter - vc_map param field settings['source'] provided icons (default empty array).
	 * If array categorized it will auto-enable category dropdown
	 *
	 * @since 4.4
	 * @return array - of icons for iconpicker, can be categorized, or not.
	 */
	function vc_iconpicker_type_themeify( $icons )
	{
		// Categorized icons ( you can also output simple array ( key=> value ), where key = icon class, value = icon readable name ).
		$themify_icons = array(
				array( "ti-wand" => "Wand"),
				array( "ti-volume" => "Volume"),
				array( "ti-user" => "User"),
				array( "ti-unlock" => "Unlock"),
				array( "ti-unlink" => "Unlink"),
				array( "ti-trash" => "Trash"),
				array( "ti-thought" => "Thought"),
				array( "ti-target" => "Target"),
				array( "ti-tag" => "Tag"),
				array( "ti-tablet" => "Tablet"),
				array( "ti-star" => "Star"),
				array( "ti-spray" => "Star"),
				array( "ti-signal" => "Signal"),
				array( "ti-shopping-cart" => "Shopping cart"),
				array( "ti-shopping-cart-full" => "Shopping cart full"),
				array( "ti-settings" => "Settings"),
				array( "ti-search" => "Search"),
				array( "ti-zoom-in" => "Zoom in"),
				array( "ti-zoom-out" => "Zoom out"),
				array( "ti-cut" => "Cut"),
				array( "ti-ruler" => "Ruler"),
				array( "ti-ruler-pencil" => "Ruler pencil"),
				array( "ti-ruler-alt" => "Ruler alt"),
				array( "ti-bookmark" => "Bookmark"),
				array( "ti-bookmark-alt" => "Bookmark alt"),
				array( "ti-reload" => "Reload"),
				array( "ti-plus" => "Plus"),
				array( "ti-pin" => "Plus"),
				array( "ti-pencil" => "Pencil"),
				array( "ti-pencil-alt" => "Pencil alt"),
				array( "ti-paint-roller" => "Paint roller"),
				array( "ti-paint-bucket" => "Paint bucket"),
				array( "ti-na" => "Na"),
				array( "ti-mobile" => "Mobile"),
				array( "ti-minus" => "Minus"),
				array( "ti-medall" => "Medall"),
				array( "ti-medall-alt" => "Medall alt"),
				array( "ti-marker" => "Marker"),
				array( "ti-marker-alt" => "Marker alt"),
				array( "ti-arrow-up" => "Arrow up"),
				array( "ti-arrow-right" => "Arrow right"),
				array( "ti-arrow-left" => "Arrow left"),
				array( "ti-arrow-down" => "Arrow down"),
				array( "ti-lock" => "Lock"),
				array( "ti-location-arrow" => "Lock"),
				array( "ti-link" => "Link"),
				array( "ti-layout" => "Layout"),
				array( "ti-layers" => "Layers"),
				array( "ti-layers-alt" => "Layers alt"),
				array( "ti-key" => "Key"),
				array( "ti-import" => "Import"),
				array( "ti-image" => "Image"),
				array( "ti-heart" => "Image"),
				array( "ti-heart-broken" => "Heart broken"),
				array( "ti-hand-stop" => "Hand stop"),
				array( "ti-hand-open" => "Hand open"),
				array( "ti-hand-drag" => "Hand drag"),
				array( "ti-folder" => "Folder"),
				array( "ti-flag" => "Flag"),
				array( "ti-flag-alt" => "Flag alt"),
				array( "ti-flag-alt-2" => "Flag alt 2"),
				array( "ti-eye" => "Eye"),
				array( "ti-export" => "Export"),
				array( "ti-exchange-vertical" => "Exchange vertical"),
				array( "ti-desktop" => "Desktop"),
				array( "ti-cup" => "Cup"),
				array( "ti-crown" => "Crown"),
				array( "ti-comments" => "Comments"),
				array( "ti-comment" => "Comment"),
				array( "ti-comment-alt" => "Comment alt"),
				array( "ti-close" => "Close"),
				array( "ti-clip" => "Clip"),
				array( "ti-angle-up" => "Angle-up"),
				array( "ti-angle-right" => "Angle right"),
				array( "ti-angle-left" => "Angle left"),
				array( "ti-angle-down" => "Angle down"),
				array( "ti-check" => "Check"),
				array( "ti-check-box" => "Check box"),
				array( "ti-camera" => "Camera"),
				array( "ti-announcement" => "Announcement"),
				array( "ti-brush" => "Brush"),
				array( "ti-briefcase" => "Briefcase"),
				array( "ti-bolt" => "Bolt"),
				array( "ti-bolt-alt" => "Bolt alt"),
				array( "ti-blackboard" => "Blackboard"),
				array( "ti-bag" => "Bag"),
				array( "ti-move" => "Move"),
				array( "ti-arrows-vertical" => "Arrows vertical"),
				array( "ti-arrows-horizontal" => "Arrows horizontal"),
				array( "ti-fullscreen" => "Fullscreen"),
				array( "ti-arrow-top-right" => "Arrow top right"),
				array( "ti-arrow-top-left" => "Arrow top left"),
				array( "ti-arrow-circle-up" => "Arrow circle up"),
				array( "ti-arrow-circle-right" => "Arrow circle right"),
				array( "ti-arrow-circle-left" => "Arrow circle left"),
				array( "ti-arrow-circle-down" => "Arrow circle down"),
				array( "ti-angle-double-up" => "Angle double up"),
				array( "ti-angle-double-right" => "Angle double right"),
				array( "ti-angle-double-left" => "Angle double left"),
				array( "ti-angle-double-down" => "Angle double down"),
				array( "ti-zip" => "Zip"),
				array( "ti-world" => "World"),
				array( "ti-wheelchair" => "Wheelchair"),
				array( "ti-view-list" => "View list"),
				array( "ti-view-list-alt" => "View list alt"),
				array( "ti-view-grid" => "View grid"),
				array( "ti-uppercase" => "Uppercase"),
				array( "ti-upload" => "Upload"),
				array( "ti-underline" => "Underline"),
				array( "ti-truck" => "Truck"),
				array( "ti-timer" => "Timer"),
				array( "ti-ticket" => "Ticket"),
				array( "ti-thumb-up" => "Thumb up"),
				array( "ti-thumb-down" => "Thumb down"),
				array( "ti-text" => "Text"),
				array( "ti-stats-up" => "Stats up"),
				array( "ti-stats-down" => "Stats down"),
				array( "ti-split-v" => "Split v"),
				array( "ti-split-h" => "Split h"),
				array( "ti-smallcap" => "Smallcap"),
				array( "ti-shine" => "Shine"),
				array( "ti-shift-right" => "Shift right"),
				array( "ti-shift-left" => "Shift left"),
				array( "ti-shield" => "Shield"),
				array( "ti-notepad" => "Notepad"),
				array( "ti-server" => "Server"),
				array( "ti-quote-right" => "Quote right"),
				array( "ti-quote-left" => "Quote left"),
				array( "ti-pulse" => "Pulse"),
				array( "ti-printer" => "Printer"),
				array( "ti-power-off" => "Power off"),
				array( "ti-plug" => "Plug"),
				array( "ti-pie-chart" => "Pie chart"),
				array( "ti-paragraph" => "Pie chart"),
				array( "ti-panel" => "Panel"),
				array( "ti-package" => "Package"),
				array( "ti-music" => "Music"),
				array( "ti-music-alt" => "Music alt"),
				array( "ti-mouse" => "Mouse"),
				array( "ti-mouse-alt" => "Mouse alt"),
				array( "ti-money" => "Money"),
				array( "ti-microphone" => "Microphone"),
				array( "ti-menu" => "Menu"),
				array( "ti-menu-alt" => "Menu alt"),
				array( "ti-map" => "Map"),
				array( "ti-map-alt" => "Map alt"),
				array( "ti-loop" => "Loop"),
				array( "ti-location-pin" => "Location pin"),
				array( "ti-list" => "List"),
				array( "ti-light-bulb" => "Light bulb"),
				array( "ti-Italic" => "Italic"),
				array( "ti-info" => "Info"),
				array( "ti-infinite" => "Infinite"),
				array( "ti-id-badge" => "Id-badge"),
				array( "ti-hummer" => "Hummer"),
				array( "ti-home" => "Home"),
				array( "ti-help" => "Help"),
				array( "ti-headphone" => "Headphone"),
				array( "ti-harddrives" => "Harddrives"),
				array( "ti-harddrive" => "Harddrive"),
				array( "ti-gift" => "Gift"),
				array( "ti-game" => "Game"),
				array( "ti-filter" => "Filter"),
				array( "ti-files" => "Files"),
				array( "ti-file" => "File"),
				array( "ti-eraser" => "Eraser"),
				array( "ti-envelope" => "Envelope"),
				array( "ti-download" => "Download"),
				array( "ti-direction" => "Direction"),
				array( "ti-direction-alt" => "Direction alt"),
				array( "ti-dashboard" => "Dashboard"),
				array( "ti-control-stop" => "Control stop"),
				array( "ti-control-shuffle" => "Control shuffle"),
				array( "ti-control-play" => "Control play"),
				array( "ti-control-pause" => "Control pause"),
				array( "ti-control-forward" => "Control forward"),
				array( "ti-control-backward" => "Control backward"),
				array( "ti-cloud" => "Cloud"),
				array( "ti-cloud-up" => "Cloud up"),
				array( "ti-cloud-down" => "Cloud down"),
				array( "ti-clipboard" => "Clipboard"),
				array( "ti-car" => "Car"),
				array( "ti-calendar" => "Calendar"),
				array( "ti-book" => "Book"),
				array( "ti-bell" => "Bell"),
				array( "ti-basketball" => "Basketball"),
				array( "ti-bar-chart" => "Bar chart"),
				array( "ti-bar-chart-alt" => "Bar chart alt"),
				array( "ti-back-right" => "Back right"),
				array( "ti-back-left" => "Back left"),
				array( "ti-arrows-corner" => "Arrows corner"),
				array( "ti-archive" => "Archive"),
				array( "ti-anchor" => "Anchor"),
				array( "ti-align-right" => "Align right"),
				array( "ti-align-left" => "Align left"),
				array( "ti-align-justify" => "Align justify"),
				array( "ti-align-center" => "Align center"),
				array( "ti-alert" => "Alert"),
				array( "ti-alarm-clock" => "Alarm clock"),
				array( "ti-agenda" => "Agenda"),
				array( "ti-write" => "Write"),
				array( "ti-window" => "Window"),
				array( "ti-widgetized" => "Widgetized"),
				array( "ti-widget" => "Widget"),
				array( "ti-widget-alt" => "Widget alt"),
				array( "ti-wallet" => "Wallet"),
				array( "ti-video-clapper" => "Video clapper"),
				array( "ti-video-camera" => "Video clapper"),
				array( "ti-vector" => "Vector"),
				array( "ti-themify-logo" => "Themify logo"),
				array( "ti-themify-favicon" => "Themify favicon"),
				array( "ti-themify-favicon-alt" => "Themify favicon-alt"),
				array( "ti-support" => "Support"),
				array( "ti-stamp" => "Stamp"),
				array( "ti-split-v-alt" => "Split v alt"),
				array( "ti-slice" => "Slice"),
				array( "ti-shortcode" => "Shortcode"),
				array( "ti-shift-right-alt" => "Shift right alt"),
				array( "ti-shift-left-alt" => "Shift left alt"),
				array( "ti-ruler-alt-2" => "Ruler alt 2"),
				array( "ti-receipt" => "Receipt"),
				array( "ti-pin2" => "Pin2"),
				array( "ti-pin-alt" => "Pin alt"),
				array( "ti-pencil-alt2" => "Pencil alt2"),
				array( "ti-palette" => "Palette"),
				array( "ti-more" => "More"),
				array( "ti-more-alt" => "More alt"),
				array( "ti-microphone-alt" => "Microphone alt"),
				array( "ti-magnet" => "Magnet"),
				array( "ti-line-double" => "Line double"),
				array( "ti-line-dotted" => "Line dotted"),
				array( "ti-line-dashed" => "Line dashed"),
				array( "ti-layout-width-full" => "Layout width full"),
				array( "ti-layout-width-default" => "Layout width default"),
				array( "ti-layout-width-default-alt" => "Layout width default alt"),
				array( "ti-layout-tab" => "Layout tab"),
				array( "ti-layout-tab-window" => "Layout tab window"),
				array( "ti-layout-tab-v" => "Layout tab v"),
				array( "ti-layout-tab-min" => "Layout tab min"),
				array( "ti-layout-slider" => "Layout slider"),
				array( "ti-layout-slider-alt" => "Layout slider alt"),
				array( "ti-layout-sidebar-right" => "Layout sidebar right"),
				array( "ti-layout-sidebar-none" => "Layout sidebar none"),
				array( "ti-layout-sidebar-left" => "Layout sidebar left"),
				array( "ti-layout-placeholder" => "Layout placeholder"),
				array( "ti-layout-menu" => "Layout menu"),
				array( "ti-layout-menu-v" => "Layout menu v"),
				array( "ti-layout-menu-separated" => "Layout menu separated"),
				array( "ti-layout-menu-full" => "Layout menu full"),
				array( "ti-layout-media-right-alt" => "Layout media right alt"),
				array( "ti-layout-media-right" => "Layout media right"),
				array( "ti-layout-media-overlay" => "Layout media overlay"),
				array( "ti-layout-media-overlay-alt" => "Layout media overlay alt"),
				array( "ti-layout-media-overlay-alt-2" => "Layout media overlay alt 2"),
				array( "ti-layout-media-left-alt" => "Layout media left alt"),
				array( "ti-layout-media-left" => "Layout media left"),
				array( "ti-layout-media-center-alt" => "Layout media center alt"),
				array( "ti-layout-media-center" => "Layout media center"),
				array( "ti-layout-list-thumb" => "Layout list thumb"),
				array( "ti-layout-list-thumb-alt" => "Layout list thumb alt"),
				array( "ti-layout-list-post" => "Layout list post"),
				array( "ti-layout-list-large-image" => "Layout list large image"),
				array( "ti-layout-line-solid" => "Layout line solid"),
				array( "ti-layout-grid4" => "Layout grid4"),
				array( "ti-layout-grid3" => "Layout grid3"),
				array( "ti-layout-grid2" => "Layout grid2"),
				array( "ti-layout-grid2-thumb" => "Layout grid2 thumb"),
				array( "ti-layout-cta-right" => "Layout cta right"),
				array( "ti-layout-cta-left" => "Layout cta left"),
				array( "ti-layout-cta-center" => "Layout cta center"),
				array( "ti-layout-cta-btn-right" => "Layout cta btn right"),
				array( "ti-layout-cta-btn-left" => "Layout cta btn left"),
				array( "ti-layout-column4" => "Layout column4"),
				array( "ti-layout-column3" => "Layout column3"),
				array( "ti-layout-column2" => "Layout column2"),
				array( "ti-layout-accordion-separated" => "Layout accordion separated"),
				array( "ti-layout-accordion-merged" => "Layout accordion merged"),
				array( "ti-layout-accordion-list" => "Layout accordion list"),
				array( "ti-ink-pen" => "Ink pen"),
				array( "ti-info-alt" => "Info alt"),
				array( "ti-help-alt" => "Help alt"),
				array( "ti-headphone-alt" => "Headphone alt"),
				array( "ti-hand-point-up" => "Hand-point up"),
				array( "ti-hand-point-right" => "Hand-point right"),
				array( "ti-hand-point-left" => "Hand-point left"),
				array( "ti-hand-point-down" => "Hand-point left"),
				array( "ti-gallery" => ""),
				array( "ti-face-smile" => "Face smile"),
				array( "ti-face-sad" => "Face sad"),
				array( "ti-credit-card" => "Credit-card"),
				array( "ti-control-skip-forward" => "Control skip forward"),
				array( "ti-control-skip-backward" => "Control skip backward"),
				array( "ti-control-record" => "Control record"),
				array( "ti-control-eject" => "Control eject"),
				array( "ti-comments-smiley" => "Control eject"),
				array( "ti-brush-alt" => "Brush alt"),
				array( "ti-youtube" => ""),
				array( "ti-vimeo" => "Vimeo"),
				array( "ti-twitter" => "Vimeo"),
				array( "ti-time" => "Time"),
				array( "ti-tumblr" => "Tumblr"),
				array( "ti-skype" => "Skype"),
				array( "ti-share" => "Share"),
				array( "ti-share-alt" => "Share"),
				array( "ti-rocket" => "Rocket"),
				array( "ti-pinterest" => "Pinterest"),
				array( "ti-new-window" => "New-window"),
				array( "ti-microsoft" => "Microsoft"),
				array( "ti-list-ol" => "List ol"),
				array( "ti-linkedin" => "Linkedin"),
				array( "ti-layout-sidebar-2" => "Layout sidebar 2"),
				array( "ti-layout-grid4-alt" => "Layout grid4 alt"),
				array( "ti-layout-grid3-alt" => "Layout grid3 alt"),
				array( "ti-layout-grid2-alt" => "Layout grid2 alt"),
				array( "ti-layout-column4-alt" => "Layout column4 alt"),
				array( "ti-layout-column3-alt" => "Layout column3 alt"),
				array( "ti-layout-column2-alt" => "Layout column3 alt"),
				array( "ti-instagram" => "Instagram"),
				array( "ti-google" => "Google"),
				array( "ti-github" => "Github"),
				array( "ti-flickr" => "Flickr"),
				array( "ti-facebook" => "Facebook"),
				array( "ti-dropbox" => "Dropbox"),
				array( "ti-dribbble" => "Dribbble"),
				array( "ti-apple" => "Apple"),
				array( "ti-android" => "Android"),
				array( "ti-save" => "Save"),
				array( "ti-save-alt" => "Save alt"),
				array( "ti-yahoo" => "Save alt"),
				array( "ti-wordpress" => "Wordpress"),
				array( "ti-vimeo-alt" => "Vimeo alt"),
				array( "ti-twitter-alt" => "Twitter alt"),
				array( "ti-tumblr-alt" => "Tumblr alt"),
				array( "ti-trello" => "Trello"),
				array( "ti-stack-overflow" => "Stack overflow"),
				array( "ti-soundcloud" => "Soundcloud"),
				array( "ti-sharethis" => "Sharethis"),
				array( "ti-sharethis-alt" => "Sharethis alt"),
				array( "ti-reddit" => "Reddit"),
				array( "ti-pinterest-alt" => "Pinterest alt"),
				array( "ti-microsoft-alt" => "Microsoft alt"),
				array( "ti-linux" => "Linux"),
				array( "ti-jsfiddle" => "Jsfiddle"),
				array( "ti-joomla" => "Joomla"),
				array( "ti-html5" => "Html5"),
				array( "ti-flickr-alt" => "Flickr alt"),
				array( "ti-email" => "Email"),
				array( "ti-drupal" => "Drupal"),
				array( "ti-dropbox-alt" => "Dropbox alt"),
				array( "ti-css3" => "Css3"),
				array( "ti-rss" => "Rss"),
				array( "ti-rss-alt" => "Rss alt"),
		);

		return $themify_icons;
	}
}


add_action( 'init', 'bolder_register_vc_shortcodes' , 10000);
function bolder_register_vc_shortcodes() {

	if (class_exists('Vc_Manager')) {
		//****************************************************** Variable ******************************************************//
		/*$add_css_animation = array(
			"type" => "dropdown",
			"heading" => __("CSS Animation", 'bolder'),
			"param_name" => "css_animation",
			"admin_label" => false,
			"value" => array(__("No", 'bolder') => '', __("Top to bottom", 'bolder') => "top-to-bottom", __("Bottom to top", 'bolder') => "bottom-to-top", __("Left to right", 'bolder') => "left-to-right", __("Right to left", 'bolder') => "right-to-left", __("Appear from center", 'bolder') => "appear"),
			"description" => __("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'bolder')
		);*/

		$add_yes_no = array(
			'type' => 'checkbox',
			'heading' => __( 'Choose Animation', 'bolder' ),
			'param_name' => 'onclick',
			'description' => __( 'Define action for choose event if needed.', 'bolder' )
		);
		$add_css_animation = array(
			'type' => 'dropdown',
			'heading' => __( 'CSS Animation', 'bolder' ),
			'param_name' => 'css_animation',
			'admin_label' => true,
			'value' => array(
				__( 'bounce', 'bolder' ) => 'bounce',
				__( 'rubberBand', 'bolder' ) => 'rubberBand',
				__( 'flash', 'bolder' ) => 'flash',
				__( 'pulse', 'bolder' ) => 'pulse',
				__( 'shake', 'bolder' ) => 'shake',
				__( 'swing', 'bolder' ) => 'swing',
				__( 'tada', 'bolder' ) => 'tada',
				__( 'wobble', 'bolder' ) => 'wobble',

				__( 'bounceIn', 'bolder' ) => 'bounceIn',
				__( 'bounceInDown', 'bolder' ) => 'bounceInDown',
				__( 'bounceInLeft', 'bolder' ) => 'bounceInLeft',
				__( 'bounceInRight', 'bolder' ) => 'bounceInRight',
				__( 'bounceInUp', 'bolder' ) => 'bounceInUp',
				__( 'bounceOut', 'bolder' ) => 'bounceOut',
				__( 'bounceOutDown', 'bolder' ) => 'bounceOutDown',
				__( 'bounceOutLeft', 'bolder' ) => 'bounceOutLeft',
				__( 'bounceOutRight', 'bolder' ) => 'bounceOutRight',
				__( 'bounceOutUp', 'bolder' ) => 'bounceOutUp',
				__( 'fadeIn', 'bolder' ) => 'fadeIn',
				__( 'fadeInDown', 'bolder' ) => 'fadeInDown',
				__( 'fadeInDownBig', 'bolder' ) => 'fadeInDownBig',
				__( 'fadeInLeft', 'bolder' ) => 'fadeInLeft',
				__( 'fadeInLeftBig', 'bolder' ) => 'fadeInLeftBig',
				__( 'fadeInRight', 'bolder' ) => 'fadeInRight',
				__( 'fadeInRightBig', 'bolder' ) => 'fadeInRightBig',
				__( 'fadeInUp', 'bolder' ) => 'fadeInUp',
				__( 'fadeInUpBig', 'bolder' ) => 'fadeInUpBig',
				__( 'fadeOut', 'bolder' ) => 'fadeOut',
				__( 'fadeOutDown', 'bolder' ) => 'fadeOutDown',
				__( 'fadeOutDownBig', 'bolder' ) => 'fadeOutDownBig',
				__( 'fadeOutLeft', 'bolder' ) => 'fadeOutLeft',
				__( 'fadeOutLeftBig', 'bolder' ) => 'fadeOutLeftBig',
				__( 'fadeOutRight', 'bolder' ) => 'fadeOutRight',
				__( 'fadeOutRightBig', 'bolder' ) => 'fadeOutRightBig',
				__( 'fadeOutUp', 'bolder' ) => 'fadeOutUp',
				__( 'fadeOutUpBig', 'bolder' ) => 'fadeOutUpBig',
				__( 'flip', 'bolder' ) => 'flip',
				__( 'flipInX', 'bolder' ) => 'flipInX',
				__( 'flipInY', 'bolder' ) => 'flipInY',
				__( 'flipOutX', 'bolder' ) => 'flipOutX',
				__( 'flipOutY', 'bolder' ) => 'flipOutY',
				__( 'lightSpeedIn', 'bolder' ) => 'lightSpeedIn',
				__( 'lightSpeedOut', 'bolder' ) => 'lightSpeedOut',
				__( 'rotateIn', 'bolder' ) => 'rotateIn',
				__( 'rotateInDownLeft', 'bolder' ) => 'rotateInDownLeft',
				__( 'rotateInDownRight', 'bolder' ) => 'rotateInDownRight',
				__( 'rotateInUpLeft', 'bolder' ) => 'rotateInUpLeft',
				__( 'rotateInUpRight', 'bolder' ) => 'rotateInUpRight',
				__( 'rotateOut', 'bolder' ) => 'rotateOut',
				__( 'rotateOutDownLeft', 'bolder' ) => 'rotateOutDownLeft',
				__( 'rotateOutDownRight', 'bolder' ) => 'rotateOutDownRight',
				__( 'rotateOutUpLeft', 'bolder' ) => 'rotateOutUpLeft',
				__( 'rotateOutUpRight', 'bolder' ) => 'rotateOutUpRight',
				__( 'hinge', 'bolder' ) => 'hinge',
				__( 'rollIn', 'bolder' ) => 'rollIn',
				__( 'rollOut', 'bolder' ) => 'rollOut',

				__( 'zoomIn', 'bolder' ) => 'zoomIn',
				__( 'zoomInDown', 'bolder' ) => 'zoomInDown',
				__( 'zoomInLeft', 'bolder' ) => 'zoomInLeft',
				__( 'zoomInRight', 'bolder' ) => 'zoomInRight',
				__( 'zoomInUp', 'bolder' ) => 'zoomInUp',
				__( 'zoomOut', 'bolder' ) => 'zoomOut',
				__( 'zoomOutDown', 'bolder' ) => 'zoomOutDown',
				__( 'zoomOutLeft', 'bolder' ) => 'zoomOutLeft',
				__( 'zoomOutRight', 'bolder' ) => 'zoomOutRight',
				__( 'zoomOutUp', 'bolder' ) => 'zoomOutUp',
				__( 'Appear from center', 'bolder' ) => "appear"
			),
			'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'bolder' ),
			'dependency' => array(
				'element' => 'onclick',
				'value' => "true"
			)
		);

		$data_wow_delay = array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Data Wow Delay",'bolder'),
			"param_name" => "data_wow_delay",
			"value" => "",
			"description" => __("Data Wow Delay eg:0.2s,0.3s ...",'bolder'),
			'dependency' => array(
				'element' => 'onclick',
				'value' => "true"
			)
		);
		$data_wow_duration = array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Data Wow Duration",'bolder'),
			"param_name" => "data_wow_duration",
			"value" => "",
			"description" => __("Data Wow Duration eg:0.2s,0.3s ...",'bolder'),
			'dependency' => array(
				'element' => 'onclick',
				'value' => "true"
			)
		);
		$add_css_style = array(
			'type' => 'css_editor',
			'heading' => __( 'Css', 'bolder' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'bolder' )
		);

		/*$add_css_awesome = array(
			'type' => 'textfield',
			'heading' => __( 'font awesome icon class', 'bolder' ),
			'param_name' => 'css_awesome',
			'admin_label' => true,
			'value' => '',
			'description' => __( 'Enter font icon awesome .eg: fa-facebook... . <a target="__blank" href="http://fortawesome.github.io/Font-Awesome/icons/">click here.</a>', 'bolder' ),
		);*/

//******************************************************************************************************/
// Custom VC Column
//******************************************************************************************************/
		vc_add_param('vc_column', $add_yes_no);
		vc_add_param('vc_column', $add_css_animation);
		vc_add_param('vc_column', $data_wow_delay);
		vc_add_param('vc_column', $data_wow_duration);
		vc_add_param('vc_column_inner', $add_yes_no);
		vc_add_param('vc_column_inner', $add_css_animation);
		vc_add_param('vc_column_inner', $data_wow_delay);
		vc_add_param('vc_column_inner', $data_wow_duration);
//******************************************************************************************************/
// Custom VC Row  
//******************************************************************************************************/	
		$setting = array(
			'type' => 'colorpicker',
			'holder' => 'div',
			'class' => '',
			'heading' => __( 'Background overlay', 'bolder' ),
			'param_name' => 'color_overlay',
			'value' =>'',
			'description' => ""
		);
		vc_add_param( 'vc_row', $setting );
		$setting = array(
			"type" => "dropdown",
			"heading" => __('Text Color Scheme', 'bolder'),
			"param_name" => "text_scheme",
			"description" => __("Pick a color scheme for the content text. 'Light Text' looks good on dark bg images while 'Dark Text' looks good on light images.", 'bolder'),
			"value" => array(
				__("Default (Darker Text)", 'bolder') => '',
				__("Dark Text", 'bolder') => 'lighter-overlay',
				__("Light Text", 'bolder') => 'darker-overlay'
			)
		);
		vc_add_param( 'vc_row', $setting );

		//vc_remove_param( "vc_row", "parallax" );
		$setting = array(
			'type' => 'dropdown',
			'heading' => __( 'Parallax', 'js_composer' ),
			'param_name' => 'parallax',
			'value' => array(
				__( 'None', 'js_composer' ) => '',
				__( 'Simple', 'js_composer' ) => 'content-moving',
				__( 'With fade', 'js_composer' ) => 'content-moving-fade',
				__( 'Fixed', 'js_composer' ) => 'fixed',
			),
			'description' => __( 'Add parallax type background for row (Note: If no image is specified, parallax will use background image from Design Options).', 'js_composer' ),
			'dependency' => array(
				'element' => 'video_bg',
				'is_empty' => true,
			),
		);

		vc_add_param( 'vc_row', $setting );
		$setting = array(
			'type' => 'column_offset',
			'heading' => __('Responsiveness', 'js_composer'),
			'param_name' => 'offset',
			'group' => __( 'Width & Responsiveness', 'js_composer' ),
			'description' => __('Adjust column for different screen sizes. Control width, offset and visibility settings.', 'js_composer')
		);
		vc_add_param( 'vc_column_inner', $setting );


//******************************************************************************************************/
// Blockquote
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Block Quote", 'bolder'),
			"description" => "Display style blockquote",
			"base" => "bolder_blockquote",
			"class" => "",
			"category" => __("For bolder theme", 'bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style quote', 'bolder' ),
					'param_name' => 'style',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style1',
						__( 'Style 2', 'bolder' ) => 'style2',
					),
					'description' => __( 'Choose style for Blockquote.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Author name",'bolder'),
					"param_name" => "name_author",
					"value" => "Robert Smith",
					"description" => __("Add author name for quote.",'bolder')
				),
				array(
					"type" => "textarea_html",
					"holder" => "div",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" =>'Synergistically supply global testing procedures through ethical scenarios develop empowered sticky leadership.',
					"description" => __("content",'bolder')
				),
			)
		) );
//******************************************************************************************************/
// Button
//******************************************************************************************************/
	vc_map( array(
		"name" => __("Simple Button",'bolder'),
		"base" => "bolder_simple_button",
		"category" => __('For bolder theme','bolder'),
		"params" => array(
			array(
				"type" => "textfield",
				"admin_label" => true,
				"heading" => __("Text",'bolder'),
				"param_name" => "content",
				"value" => __("Bolder theme",'bolder'),
				"description" => __("Enter button text",'bolder')
			),
			array(
				"type" => "textfield",
				"admin_label" => true,
				"heading" => __("Link",'bolder'),
				"param_name" => "link",
				"value" => '#',
				"description" => __("Enter button link",'bolder')
			),
			array(
				"type" => "dropdown",
				"admin_label" => true,
				"heading" => __("Color",'bolder'),
				"param_name" => "color",
				"value" => array(
					__('Accent color', 'bolder') => 'accent',
					__('Red', 'bolder') => 'red',
					__('Dark', 'bolder') => 'dark',
					__('Gray', 'bolder') => 'gray',
				),
				"description" => __("Select button color",'bolder')
			),
			array(
				"type" => "dropdown",
				"admin_label" => true,
				"heading" => __("Size",'bolder'),
				"param_name" => "size",
				"value" => array(
					__('Normal', 'bolder') => 'normal',
					__('Large', 'bolder') => 'large',
				),
				"description" => __("Select button size",'bolder')
			),
			array(
				"type" => "textfield",
				"heading" => __("Class name",'bolder'),
				"param_name" => "el_class",
				"value" => "",
				"description" => __("Add class name for element",'bolder')
			),
			$add_css_style,
		)
	));

//******************************************************************************************************/
// Style button
//******************************************************************************************************/
		$add_style_border = array(
			'type' => 'dropdown',
			'heading' => __( 'Choose style border', 'bolder' ),
			'param_name' => 'style_border_button',
			'value' =>array(
				__( 'solid','bolder')=>'solid',
				__( 'dotted','bolder')=>'dotted',
				__( 'dashed','bolder')=>'dashed',
				__( 'none','bolder')=>'none',
				__( 'hidden','bolder')=>'hidden',
				__( 'double','bolder')=>'double',
				__( 'groove','bolder')=>'groove',
				__( 'ridge','bolder')=>'ridge',
				__( 'inset','bolder')=>'inset',
				__( 'outset','bolder')=>'outset',
				__( 'initial','bolder')=>'initial',
				__( 'inherit','bolder')=>'inherit'
			),
			'dependency' => array(
				'element' => 'border_button',
				'value' => array( 'yes' )
			),
			'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'bolder' ),
		);
		vc_map( array(
			"name" => __("Advanced button", 'bolder'),
			"base" => "bolder_advanced_button",
			"class" => "",
			"category" => __("For bolder theme", 'bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Layout display', 'bolder' ),
					'param_name' => 'size_button',
					'value' => array(
						__( 'Large', 'bolder' ) => 'large',
						__( 'Normal', 'bolder' ) => 'normal',
						__( 'Small', 'bolder' ) => 'small',
					),
					'description' => __( 'Choose Layout display.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Text button",'bolder'),
					"param_name" => "content",
					"value" => __("Button","bolder"),
					"description" => __("Add button name for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Link button",'bolder'),
					"param_name" => "link_button",
					"value" => "#",
					"description" => __("Add button link for element",'bolder')
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Postion button', 'bolder' ),
					'param_name' => 'postion_button',
					'value' => array(
						__( 'Left', 'bolder' ) => 'pull-left',
						__( 'Right', 'bolder' ) => 'pull-right',
					),
					'description' => __( 'Choose Postion display for button.', 'bolder' )
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Color text","bolder"),
					"param_name" => "color_text_button",
					"value" => '#ffffff', //Default color
					"description" => __("Choose color for text ","bolder")
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Color text hover","bolder"),
					"param_name" => "color_text_hover_button",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for text button when hover","bolder")
				),

				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("background button","bolder"),
					"param_name" => "color_button",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for button","bolder")
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("background button hover","bolder"),
					"param_name" => "color_hover_button",
					"value" => '#252525', //Default color
					"description" => __("Choose color when hover button.","bolder")
				),

				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose border', 'bolder' ),
					'param_name' => 'border_button',
					'value' => array(
						__( 'No border', 'bolder' ) => 'no',
						__( 'Border', 'bolder' ) => 'yes',
					),
					'description' => __( 'Choose Layout display.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Width border button",'bolder'),
					"param_name" => "width_border_button",
					"value" => "1",
					'dependency' => array(
						'element' => 'border_button',
						'value' => array( 'yes' )
					),
					"description" => __("Add border width for button",'bolder')
				),
				$add_style_border,
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __(" Choose color border","bolder"),
					"param_name" => "color_border_button",
					"value" => '#42454a', //Default color
					'dependency' => array(
						'element' => 'border_button',
						'value' => array( 'yes' )
					),
					"description" => __("Choose color for border button","bolder"),
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Width radius",'bolder'),
					"param_name" => "border_radius_width",
					"value" => "0",
					"description" => __("Enter number radius width for button",'bolder')
				),
				array(
					"type" => "textarea",
					"heading" => __("Custom css",'bolder'),
					"param_name" => "border_custom_css",
					"value" => "",
					"description" => __("Enter custom stylesheet for button. Ex color: #fff; font-size: 10px",'bolder'),
					'group' => __('Advance', 'bolder')
				),
				array(
					"type" => "textarea",
					"heading" => __("Custom css on hover",'bolder'),
					"param_name" => "border_custom_css_hover",
					"value" => "",
					"description" => __("Enter custom stylesheet for button on hover. Ex color: #fff; font-size: 10px",'bolder'),
					'group' => __('Advance', 'bolder')
				),
			)));

//******************************************************************************************************/
// Call To Action
//******************************************************************************************************/

		vc_map( array(
			"name" => __("Call To action",'bolder'),
			"base" => "bolder_call_to_action",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Title",'bolder'),
					"param_name" => "bolder_cta_title",
					"value" => "Managed Dedicated Servers",
					"description" => __("Enter Call to action title ",'bolder')
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Color title","bolder"),
					"param_name" => "color_title",
					"value" => '#ffffff', //Default color
					"description" => __("Choose color for Title","bolder")
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Text Action",'bolder'),
					"param_name" => "bolder_cta_text_link",
					"value" => "Get started",
					"description" => __("Enter Call to action text ",'bolder')
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Text button color","bolder"),
					"param_name" => "color_text_button",
					"value" => '#ffffff', //Default color
					"description" => __("Choose color for Text button","bolder")
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Text button color hover","bolder"),
					"param_name" => "color_text_button_hover",
					"value" => '#ffffff', //Default color
					"description" => __("Choose color for Text button when hover","bolder")
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Background button","bolder"),
					"param_name" => "color_button",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for background button","bolder")
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Background button hover","bolder"),
					"param_name" => "color_hover_button",
					"value" => '#2a2a2a', //Default color
					"description" => __("Choose color for background button when hover.","bolder")
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style border', 'bolder' ),
					'param_name' => 'style_border_button',
					'value' => array(
						__( 'solid','bolder')=>'solid',
						__( 'dotted','bolder')=>'dotted',
						__( 'dashed','bolder')=>'dashed',
						__( 'none','bolder')=>'none',
						__( 'hidden','bolder')=>'hidden',
						__( 'double','bolder')=>'double',
						__( 'groove','bolder')=>'groove',
						__( 'ridge','bolder')=>'ridge',
						__( 'inset','bolder')=>'inset',
						__( 'outset','bolder')=>'outset',
						__( 'initial','bolder')=>'initial',
						__( 'inherit','bolder')=>'inherit'
					),
					'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'bolder' ),
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Border button color","bolder"),
					"param_name" => "color_border_button",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for border button","bolder")
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Width border button",'bolder'),
					"param_name" => "width_border_button",
					"value" => "1",
					"description" => __("Enter width border button. default :1 ",'bolder')
				),

				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Link Action",'bolder'),
					"param_name" => "bolder_cta_url",
					"value" => "#",
					"description" => __("Enter Call to action link ",'bolder')
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Color Text call to action","bolder"),
					"param_name" => "color_text_description",
					"value" => '#2a2a2a', //Default color
					"description" => __("Choose color for text call to action ","bolder")
				),
				array(
					"type" => "textarea_html",
					"holder" => "div",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" => __("Blazing performance, supreme flexibility & superior UK based support.",'bolder'),
					"description" => __("Call to action  content",'bolder')
				),



			)));
//******************************************************************************************************/
// Client List
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Client List', 'bolder' ),
			'base' => 'bolder_client_work',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					'type' => 'attach_images',
					'heading' => __( 'Images', 'bolder' ),
					'param_name' => 'images',
					'value' => '',
					'description' => __( 'Select images from media library.', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Image size', 'bolder' ),
					'param_name' => 'img_size',
					'value' =>'client-work',
					'description' => __( 'Enter image size. Example: thumbnail, medium, large, full ,client-work . Leave empty to use "thumbnail" size.', 'bolder' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'On click', 'bolder' ),
					'param_name' => 'onclick',
					'value' => array(
						__( 'Open prettyPhoto', 'bolder' ) => 'link_image',
						__( 'Do nothing', 'bolder' ) => 'link_no',
						__( 'Open custom link', 'bolder' ) => 'custom_link'
					),
					'description' => __( 'What to do when slide is clicked?', 'bolder' )
				),
				array(
					'type' => 'exploded_textarea',
					'heading' => __( 'Custom links', 'bolder' ),
					'param_name' => 'custom_links',
					'description' => __( 'Enter links for each slide here. Divide links with linebreaks (Enter) . ', 'bolder' ),
					'dependency' => array(
						'element' => 'onclick',
						'value' => array( 'custom_link' )
					)
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Autoplay",'bolder'),
					"param_name" => "auto_play",
					"value" => array(
						__('Yes') => 'true',
						__('No') => 'false',
					),
					"description" => __("Enter value autoplay for slide. ",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Slide speed",'bolder'),
					"param_name" => "slide_speed",
					"value" => 200,
					"description" => __("Enter slide speed value in milliseconds. ",'bolder'),
					"dependency" => array(
						'element' => 'auto_play',
						'value' => 'true'
					)
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("stop on hover",'bolder'),
					"param_name" => "stop_on_hover",
					"value" => array(
						__('No') => 'false',
						__('Yes') => 'true',
					),
					"description" => __("Stop autoplay on mouse hover. ",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Display navigation",'bolder'),
					"param_name" => "navigation",
					"value" => array(
						__('Yes') => 'true',
						__('No') => 'false',
					),
					"description" => __("Display next and prev buttons.. ",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Display pagination",'bolder'),
					"param_name" => "pagination",
					"value" => array(
						__('No') => 'false',
						__('Yes') => 'true',
					),
					"description" => __("Display pagination",'bolder')
				),
				array(
					"type" => "textarea",
					"admin_label" => true,
					"heading" => __("Items Display",'bolder'),
					"description" => __("This allow you to add custom variations of items.",'bolder'),
					"param_name" => "items_display",
					"value" => "[[0, 1], [360, 2], [640, 3], [768, 4], [1024, 5], [1200, 6]]"
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Extra class name', 'bolder' ),
					'param_name' => 'el_class',
					'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bolder' )
				)
			)
		) );
//******************************************************************************************************/
// Contact Information					
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Contact Information', 'bolder' ),
			'base' => 'bolder_contact_infomation',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Title Contact",'bolder'),
					"param_name" => "title_contact",
					"value" => 'Head Office',
					"description" => __("Add Title for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Address info",'bolder'),
					"param_name" => "address_contact",
					"value" => '30 South Park Avenue, CA 94108 San Francisco USA',
					"description" => __("Add text link for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Email",'bolder'),
					"param_name" => "text_email_contact",
					"value" => 'support@bolder.com',
					"description" => __("Add Email for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Number phone",'bolder'),
					"param_name" => "phone_contact",
					"value" => '(888) 755-7585',
					"description" => __("Add Number phone  for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Number fax",'bolder'),
					"param_name" => "fax_contact",
					"value" => '(888) 755-7585',
					"description" => __("Add  Number fax url for element",'bolder')
				),
				$add_css_style,

			)));
//******************************************************************************************************/
// Countdown Shortcode
//******************************************************************************************************/

		vc_map( array(
			"name" => __("Countdown Shortcode", 'bolder'),
			"base" => "bolder_countdown",
			"class" => "",
			"category" => __("For bolder theme", 'bolder'),
			"params" => array(

				array(
					'type' => 'dropdown',
					'heading' => __( 'Layout display', 'bolder' ),
					'param_name' => 'countdown_style',
					'value' => array(
						__( 'Countdown style 1', 'bolder' ) => 'countdownstyle1',
						__( 'Countdown style 2', 'bolder' ) => 'countdownstyle2',
					),
					'description' => __( 'Choose Layout display.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Datetime",'bolder'),
					"param_name" => "date_countdown",
					"value" => "2016/01/01|00/00/00",
					"description" => __("Add date for element.Eg:YYYY/MM/DD|h/i/s",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" => "",
					"description" => __("Add class name for element",'bolder')
				),
				$add_css_style,

			)
		) );

//******************************************************************************************************/
// FunFact
//******************************************************************************************************/
		$icon_params = (array)vc_map_integrate_shortcode( 'vc_icon', 'i_', '',
			array(
				// we need only type, icon_fontawesome, icon_.., NOT color and etc
				'include_only_regex' => '/^(type|icon_\w*)/'
			),false
		);

		$params = array_merge(
			$icon_params,
			array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Number Funfact",'bolder'),
					"param_name" => "number_funfact",
					"value" => __("7854",'bolder'),
					"description" => __("Add number funfact on for element",'bolder')
				),
				array(
					"type" => "textfield",
					"heading" => __("Speed funfact",'bolder'),
					"param_name" => "speed_funfact",
					"value" => '1000',
					"description" => __("Set speed funfact for element",'bolder')
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Add comma?', 'js_composer' ),
					'param_name' => 'add_comma',
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Unit funfact",'bolder'),
					"param_name" => "unit_funfact",
					"value" => '',
					"description" => __("Add Unit funfact for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Name Funfact",'bolder'),
					"param_name" => "name_funfact",
					"value" => __("Data Transferred",'bolder'),
					"description" => __("Add Name Funfacr for element",'bolder')
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'custom',
					'heading' => __( 'More custom?', 'js_composer' ),
					'description' => __( 'You can customize title, text and border color of funfact.', 'js_composer' )
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Choose color icon","bolder"),
					"param_name" => "color_icon",
					"value" => '#fd5047',
					"description" => __("Choose color for icon","bolder"),
					"dependency" => array(
						"element" => "custom",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Choose color Text","bolder"),
					"param_name" => "color_text",
					"value" => '#fd5047',
					"description" => __("Choose color for Text","bolder"),
					"dependency" => array(
						"element" => "custom",
						"value" => "true"
					)
				),
			)
		);
		vc_map( array(
			"name" => __("Funfact Shortcode",'bolder'),
			"base" => "bolder_funfact",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => $params)
		);
//******************************************************************************************************/
// FunFact 2
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Funfact style 2",'bolder'),
			"base" => "bolder_funfact_style2",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Number Funfact",'bolder'),
					"param_name" => "number_funfact",
					"value" => __("7854",'bolder'),
					"description" => __("Add number funfact on for element",'bolder')
				),
				array(
					"type" => "textfield",
					"heading" => __("Speed funfact",'bolder'),
					"param_name" => "speed_funfact",
					"value" => '1000',
					"description" => __("Set speed funfact for element",'bolder')
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Add comma?', 'js_composer' ),
					'param_name' => 'add_comma',
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Unit funfact",'bolder'),
					"param_name" => "unit_funfact",
					"value" => '',
					"description" => __("Add Unit funfact for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Name Funfact",'bolder'),
					"param_name" => "name_funfact",
					"value" => __("Data Transferred",'bolder'),
					"description" => __("Add Name Funfacr for element",'bolder')
				),
				array(
					"type" => "textarea_html",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" => __("Compellingly transform plug-and-play expertise whereas.Authoritatively communicate quality sources vis-a-vis standards compliant.",'bolder'),
					"description" => __("Add content",'bolder')
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'custom',
					'heading' => __( 'More custom?', 'js_composer' ),
					'description' => __( 'You can customize title, text and border color of funfact.', 'js_composer' )
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Choose color Number","bolder"),
					"param_name" => "color_number",
					"value" => '#fd5047',
					"description" => __("Choose color for number","bolder"),
					"dependency" => array(
						"element" => "custom",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Choose color title","bolder"),
					"param_name" => "color_title",
					"value" => '#252525',
					"description" => __("Choose color for title","bolder"),
					"dependency" => array(
						"element" => "custom",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Choose color Text","bolder"),
					"param_name" => "color_text",
					"value" => '#737373',
					"description" => __("Choose color for Text","bolder"),
					"dependency" => array(
						"element" => "custom",
						"value" => "true"
					)
				),
			)));
//******************************************************************************************************/
// Google MAP
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Google MAP', 'bolder' ),
			'base' => 'bolder_map_shortcode',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Title map', 'bolder' ),
					'param_name' => 'title_map_title',
					'value' => 'Coronathemes',
					'description' => __( 'Title for map info', 'bolder' )
				),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"heading" => __("Style","bolder"),
					"param_name" => "style",
					"value" => array(__('Light') => 'light', __('Dark') => 'dark', __('Custom', 'bolder') => 'custom'),
					"description" => __("Choose map style.","bolder"),
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Address', 'bolder' ),
					'param_name' => 'address',
					'value' => 'ha noi',
					'description' => __( 'Address for map info', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Latitude', 'bolder' ),
					'param_name' => 'lat',
					'value' => '21.027764',
					'description' => __( 'get lat long coordinates from an address <a href="http://www.latlong.net/convert-address-to-lat-long.html">click here</a>', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Longitude', 'bolder' ),
					'param_name' => 'long',
					'value' => '105.83416',
					'description' => __( 'get lat long coordinates from an address <a href="http://www.latlong.net/convert-address-to-lat-long.html">click here</a>', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Phone', 'bolder' ),
					'param_name' => 'title_map_phone',
					'value' => '+84 (0) 1753 456789',
					'description' => __( 'Phone for map info', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Email', 'bolder' ),
					'param_name' => 'title_map_email',
					'value' => 'bolder@gmail.com',
					'description' => __( 'Phone for map info', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Website', 'bolder' ),
					'param_name' => 'title_map_website',
					'value' => 'bolder.net',
					'description' => __( 'Website for map info', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Map Height', 'bolder' ),
					'param_name' => 'height',
					'value' => '500',
					'description' => __( 'Map height', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Add class', 'bolder' ),
					'param_name' => 'css_class',
					'value' => '',
					'description' => __( 'Add class for Block element', 'bolder' )
				),

			)
		) );
//******************************************************************************************************/
// lasted blog
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Latest Posts', 'bolder' ),
			'base' => 'bolder_lastest_blog',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Number post display', 'bolder' ),
					'param_name' => 'number_post',
					'value' => '',
					'description' => __( 'Choose number posts display.', 'bolder' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose type', 'bolder' ),
					'param_name' => 'style',
					'value' => array(
						__( 'Full with', 'bolder' ) => 'full-with',
						__( 'Container', 'bolder' ) => '',
					),
					'description' => __( 'Choose type of latest post.', 'bolder' )
				),
			)));

//******************************************************************************************************/
// Messega box
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Notification Box', 'bolder' ),
			'base' => 'bolder_notifications',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					"type" => "dropdown",
					"holder" => "div",
					"heading" => __("Choose style Notification boxes or no boxes",'bolder'),
					"param_name" => "choose_style_message_box",
					'value' => array(
						__( 'No boxes', 'bolder' ) => 'no_boxed',
						__( 'Boxed', 'bolder' ) => 'boxed',
					),
					'description' =>"Choose style Notification boxes or no boxes"
				),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"heading" => __("Choose color",'bolder'),
					"param_name" => "bolder_color_title_message",
					'value' => array(
						__( 'No Color', 'bolder' ) => 'no',
						__( 'Yes color', 'bolder' ) => 'yes',
					),
					'dependency' => array(
						'element' => 'choose_style_message_box',
						'value' => array( 'boxed')
					),
					'description' =>"Choose color for title Notification boxes."
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Title box",'bolder'),
					"param_name" => "bolder_title_message",
					"value" => "Success..   Everything is good!",
					"description" => __("Add title for box.",'bolder')
				),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"heading" => __("Choose styles message box",'bolder'),
					"param_name" => "choose_style_message",
					'value' => array(
						__( 'Info', 'bolder' ) => 'info',
						__( 'Warning', 'bolder' ) => 'warning',
						__( 'Success', 'bolder' ) => 'success',
						__( 'Error', 'bolder' ) => 'error',
					),
					'description' =>""
				),
				array(
					"type" => "textarea_html",
					"holder" => "div",
					"heading" => __("Message content",'bolder'),
					"param_name" => "content",
					"value" => 'Credibly promote cross-platform internal or "organic" sources whereas real-time functionalities. Appropriately communicate leading-edge e-commerce and standardized best practices. Phosfluorescently empower error-free web services for fully researched internal or "organic" sources. ',
					'dependency' => array(
						'element' => 'choose_style_message_box',
						'value' => array( 'boxed')
					),
					"description" => __("Add text message for Block element",'bolder')
				),
			)));

//******************************************************************************************************/
// Pricing Table	
//******************************************************************************************************/
		$icon_params = (array)vc_map_integrate_shortcode( 'vc_icon', 'pricingi_', '',
			array(
				// we need only type, icon_fontawesome, icon_.., NOT color and etc
				'include_only_regex' => '/^(type|icon_\w*)/'
			),array(
				'element' => 'pricing_table_style',
				'value' => 'style3'
			)
		);

		$params = array_merge(
			array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Pricing table style ', 'bolder' ),
					'param_name' => 'pricing_table_style',
					'value' => array(
						__( 'Layout style 1', 'bolder' ) => 'style1',
						__( 'Layout style 2', 'bolder' ) => 'style2',
						__( 'Layout style 3', 'bolder' ) => 'style3',
					),
					'description' => __( 'Choose Pricing table layout needed.', 'bolder' )
				),
			),
			$icon_params,
			array(
				array(
					"type" => "attach_image",
					"holder" => "div",
					"heading" => __("Pricing image","bolder"),
					"param_name" => "pricing_image",
					"value" => '',
					'dependency' => array(
						'element' => 'pricing_table_style',
						'value' => array( 'style3' )
					),
					"description" => __("Upload image pricing","bolder")
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Subtitle",'bolder'),
					"param_name" => "pricing_subtitle",
					"value" => __("",'bolder'),
					'dependency' => array(
						'element' => 'pricing_table_style',
						'value' => array( 'style3' )
					),
					"description" => __("Add Pricing Title for element",'bolder')
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose Active', 'bolder' ),
					'param_name' => 'class_active',
					'value' => array(
						__( 'No Active', 'bolder' ) => '',
						__( 'Active', 'bolder' ) => 'active'
					),
					'dependency' => array(
						'element' => 'pricing_table_style',
						'value' => array( 'style1','style2','style3' )
					),
					'description' => __( 'Choose active pricing needed.', 'bolder' )
				),

				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Title",'bolder'),
					"param_name" => "pricing_title",
					"value" => __("Economy",'bolder'),
					"description" => __("Add Pricing Title for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Currency",'bolder'),
					"param_name" => "pricing_currency",
					"value" => __("$",'bolder'),
					"description" => __("Add Pricing Currency for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Price",'bolder'),
					"param_name" => "pricing_price",
					"value" => __("3.99",'bolder'),
					"description" => __("Add Pricing Price for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Price unit",'bolder'),
					"param_name" => "pricing_unit",
					"value" => __("pm",'bolder'),
					"description" => __("Add Pricing Price unit for element",'bolder')
				),
				array(
					"type" => "textarea_html",
					"holder" => "div",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" => __("<ul>
								<li>500 GB Disk Space</li>
								<li>100 Databases List</li>
								<li>Free Domain Registration</li>
								<li>1 Hosting Space</li>
								<li>FREE Ad Coupons</li>
							</ul>",'bolder'),
					"description" => __("Add content",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Link Button",'bolder'),
					"param_name" => "pricing_link_button",
					"value" => __("#",'bolder'),
					"description" => __("Add Pricing Link Button for element",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Pricing Text Button",'bolder'),
					"param_name" => "pricing_text_button",
					"value" => __("GET STARTED",'bolder'),
					"description" => __("Add Pricing Text Button for element",'bolder')
				),
			)
		);

		vc_map( array(
			"name" => __("Pricing Table",'bolder'),
			"base" => "bolder_pricing_table",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => $params
		));
//******************************************************************************************************/
// Process bar
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Process Bar", 'bolder'),
			"base" => "bolder_process_bar",
			"class" => "",
			"category" => __("For bolder theme", 'bolder'),
			"params" => array(

				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title skill ",'bolder'),
					"param_name" => "title_skill",
					"value" => __("Energistically evolve","bolder"),
					"description" => __("Add title for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Number skill ",'bolder'),
					"param_name" => "number_skill",
					"value" => "75",
					"description" => __("Add number for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Unit skill ",'bolder'),
					"param_name" => "unit_skill",
					"value" => "%",
					"description" => __("Add unit for element. Eg:%",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Fontsize skill ",'bolder'),
					"param_name" => "fontsize_skill",
					"value" => "30",
					"description" => __("Add fontsize for element. Eg:%",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Dimension skill ",'bolder'),
					"param_name" => "dimension_skill",
					"value" => "127",
					"description" => __("Add Dimension for element. Eg:255",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Width skill ",'bolder'),
					"param_name" => "width_skill",
					"value" => "5",
					"description" => __("Add Dimension for element. Eg:255",'bolder'),
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Skill bar background color","bolder"),
					"param_name" => "bgcolor_skill",
					"value" => '#e7e7e7', //Default color
					"description" => __("Choose color for skill bar background","bolder"),
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Percent bar background color","bolder"),
					"param_name" => "color_skill",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for percent bar","bolder"),
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'custom_skill',
					'heading' => __( 'More custom skillbar?', 'js_composer' ),
					'description' => __( 'You can customize title and text color of kill.', 'js_composer' )
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Skill title color","bolder"),
					"param_name" => "color_title_skill",
					"value" => '#252525', //Default color
					"description" => __("Choose color for Title bar ","bolder"),
					"dependency"=> array(
						"element" => "custom_skill",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Skill text color","bolder"),
					"param_name" => "color_text_skill",
					"value" => '#737373', //Default color
					"description" => __("Choose color for percent text","bolder"),
					"dependency"=> array(
						"element" => "custom_skill",
						"value" => "true"
					)
				),
				array(
					"type" => "textarea_html",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" =>'Compellingly transform plug-and-play expertise whereas efficient platforms. Authoritatively communicate quality sources vis-a-vis standards compliant partnerships.',
					"description" => __("content",'bolder'),
				),
				array(
					"type" => "textfield",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" => "",
					"description" => __("Add class name for element",'bolder')
				),
				$add_css_style,
			)
		) );

//******************************************************************************************************/
// Section/ Block title 
//******************************************************************************************************/

		vc_map( array(
			"name" => __("Section/Block Title",'bolder'),
			"base" => "bolder_title",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title primary",'bolder'),
					"param_name" => "title_primary",
					"value" => "",
					"description" => __("Enter section title primary, which is filled primary color",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title",'bolder'),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter section title. You can use a tag '{title_primary}' to include this title primary to the section title",'bolder')
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Type', 'bolder' ),
					'param_name' => 'type',
					"admin_label" => true,
					'value' => array(
						__( 'Simple', 'bolder' ) => 'simple',
						__( 'Overlap', 'bolder' ) => 'overlap'
					),
					'description' => __( 'Choose Postion Title/Section', 'bolder' )
				),
				/*array(
					"type" => "textfield",
					"heading" => __("font-size for title",'bolder'),
					"param_name" => "fontsize_title",
					"value" => "30",
					"description" => __("Enter value font-size for title.",'bolder')
				),
				*/
				array(
					'type' => 'dropdown',
					'heading' => __( 'Align title', 'bolder' ),
					'param_name' => 'align_title',
					"admin_label" => true,
					'value' => array(
						__( 'Left', 'bolder' ) => 'text-left',
						__( 'Right', 'bolder' ) => 'text-right',
						__( 'Center', 'bolder' ) => 'text-center',
					),
					'description' => __( 'Choose Postion Title/Section', 'bolder' )
				),
				/*
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Title color","bolder"),
					"param_name" => "title_color",
					"value" => '#252525', //Default color
					"description" => __("Choose color for title","bolder")
				),
				array(
					"type" => "colorpicker",
					"heading" => __("Description color","bolder"),
					"param_name" => "des_color",
					"value" => '#737373', //Default color
					"description" => __("Choose color for Description","bolder")
				),
				array(
					"type" => "textarea_html",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" =>'',
					"description" => __("Subtitle content",'bolder')
				),*/
				$add_css_style,
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" => '',
					"description" => __("Add class name for element",'bolder')
				),
			)
		));

//******************************************************************************************************/
// Bolder box
//******************************************************************************************************/

		vc_map( array(
			"name" => __("Bolder box",'bolder'),
			"base" => "bolder_box",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title",'bolder'),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter box title.",'bolder')
				),
				array(
					"type" => "textarea_html",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" =>'',
					"description" => __("Subtitle content",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Link text",'bolder'),
					"param_name" => "link_text",
					"value" => "Read more",
					"description" => __("Enter link text.",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Link",'bolder'),
					"param_name" => "link",
					"value" => "#",
					"description" => __("Enter url.",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" => "",
					"description" => __("Add class name for element",'bolder')
				),
			)
		));

//******************************************************************************************************/
// Our Service icon
//******************************************************************************************************/
		//get vc_icon params
		//icon params
		$icon_params = (array) vc_map_integrate_shortcode( 'vc_icon', 'i_', '',
			array(
				// we need only type, icon_fontawesome, icon_.., NOT color and etc
				'include_only_regex' => '/^(type|icon_\w*)/'
			),false);

		$params = array_merge(
			//style
			array(
				array(
					'type' => 'dropdown',
					"admin_label" => true,
					'heading' => __( 'Service style', 'bolder' ),
					'param_name' => 'style',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style-1',
						__( 'Style 2', 'bolder' ) => 'style-2',
					),
					'description' => __( 'Choose service style.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"heading" => __("Count number",'bolder'),
					"param_name" => "count",
					"value" => "00",
					"description" => __("Enter count number.",'bolder'),
					"dependency" => array(
						"element" => "style",
						"value" => "style-2"
					)
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Count position', 'bolder' ),
					'param_name' => 'count_position',
					'value' => array(
						__( 'Left', 'bolder' ) => 'left',
						__( 'Right', 'bolder' ) => 'right',
					),
					'description' => __( 'Choose count position.', 'bolder' ),
					"dependency" => array(
						"element" => "style",
						"value" => "style-2"
					)
				),
			),
			//icon fields
			$icon_params,

			//service fields
			array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title",'bolder'),
					"param_name" => "service_title",
					"value" => "Backups Available",
					"description" => __("Enter service title ",'bolder')
				),
				array(
					"type" => "textarea_html",
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" => __("Compellingly transform plug-and-play expertise whereas efficient platforms. Authoritatively communicate quality sources vis-a-vis standards compliant partnerships.",'bolder'),
					"description" => __("Service content",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Link service url",'bolder'),
					"param_name" => "service_url",
					"value" => "#",
					"description" => __("Enter readmore link ",'bolder')
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Show readmore', 'bolder' ),
					'param_name' => 'show_readmore',
					'value' => array(
						__( 'Hide', 'bolder' ) => '0',
						__( 'Show', 'bolder' ) => '1',
					),
					'description' => __( 'Choose show/hide readmore.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Text service url",'bolder'),
					"param_name" => "readmore_text",
					"value" => "Read more",
					"description" => __("Enter Service readmore text ",'bolder'),
					'dependency' => array(
						'element' => 'show_readmore',
						'value' => array( '1' )
					),
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'content_align',
					'value' => array(
						__('Left', 'js_composer') => 'left',
						__('Right', 'js_composer') => 'right',
						__('Center', 'js_composer') => 'center'
					),
					'heading' => __( 'Content alignemnt', 'js_composer' ),
					'description' => __( 'Select Content alignemnt.', 'js_composer' )
				),
			)
		);
		vc_map( array(
			"name" => __("Service Icon ",'bolder'),
			"base" => "bolder_service_icon",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" =>
				$params
			)
		);
//******************************************************************************************************/
// Skill Bars
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Skill Bar", 'bolder'),
			"base" => "bolder_skillbar_shortcode",
			"description" => "Display your skills with style",
			"icon" => "icon-progress-bar",
			"class" => "skillbar_extended",
			"category" => __("For bolder theme", 'bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Layout display', 'bolder' ),
					'param_name' => 'skill_bar_style',
					'value' => array(
						__( 'Skillbar style 1', 'bolder' ) => 'skillbarstyle1',
						__( 'Skillbar style 2', 'bolder' ) => 'skillbarstyle2',
						__( 'Skillbar style 3', 'bolder' ) => 'skillbarstyle3',
					),
					'description' => __( 'Choose Layout display.', 'bolder' )
				),

				array(
					"type" => "exploded_textarea",
					"admin_label" => true,
					"heading" => __("Graphic values", 'bolder'),
					"param_name" => "values",
					"value" => "90|Development",
					"description" => __("Input graph values here. Divide values with linebreaks (Enter). Example: 90|Development.", 'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Units", 'bolder'),
					"param_name" => "units",
					"value" => "%",
					"description" => __("Enter measurement units (if needed) Eg. %, px, points, etc. Graph value and unit will be appended to the graph title.", 'bolder')
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'custom_skillbar',
					'heading' => __( 'Custom skillbar?', 'js_composer' ),
					'description' => __( 'You can customize background, percent and text color of killbar.', 'js_composer' )
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Skill bar background color","bolder"),
					"param_name" => "skillbar_background_color",
					"value" => '#e7e7e7', //Default color
					"description" => __("Choose color for skill bar background","bolder"),
					"dependency"=> array(
						"element" => "custom_skillbar",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Percent bar background color","bolder"),
					"param_name" => "percentbar_background_color",
					"value" => '#fd5047', //Default color
					"description" => __("Choose color for percent bar","bolder"),
					"dependency"=> array(
						"element" => "custom_skillbar",
						"value" => "true"
					)
				),
				array(
					"type" => "colorpicker",
					"admin_label" => true,
					"heading" => __("Skill bar text color","bolder"),
					"param_name" => "skill_bar_text_color",
					"value" => '#ffffff', //Default color
					"description" => __("Choose color for percent text","bolder"),
					"dependency"=> array(
						"element" => "custom_skillbar",
						"value" => "true"
					)

				),
				array(
					"type" => "textarea_html",
					"heading" => __("Skill bar description",'bolder'),
					"param_name" => "content",
					"value" => "",
					'dependency' => array(
						'element' => 'skill_bar_style',
						'value' => array( 'skillbarstyle1' )
					),
				),
				$add_css_style,
			)
		) );
//******************************************************************************************************/
// Team Member
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Team Member",'bolder'),
			"base" => "bolder_team_member",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style team', 'bolder' ),
					'param_name' => 'choose_style_team',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style1',
						__( 'Style 2', 'bolder' ) => 'style2',
					),
					'description' => __( 'Choose style for Team member.', 'bolder' )
				),
				array(
					"type" => "attach_image",
					"admin_label" => true,
					"heading" => __("Member's avatar","bolder"),
					"param_name" => "bg_member",
					"value" => '',
					"description" => __("Upload member's avatar","bolder")
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's name",'bolder'),
					"param_name" => "name_member",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's postion",'bolder'),
					"param_name" => "member_postion",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's twitter url",'bolder'),
					"param_name" => "fa_tiwtter",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's behance url",'bolder'),
					"param_name" => "fa_behance",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's dribble url",'bolder'),
					"param_name" => "fa_dribble",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's facebook url",'bolder'),
					"param_name" => "fa_facebook",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's youtube url",'bolder'),
					"param_name" => "fa_youtube",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's google url",'bolder'),
					"param_name" => "fa_google",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's tumblr url",'bolder'),
					"param_name" => "fa_tumblr",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Member's vine url",'bolder'),
					"param_name" => "fa_vine",
					"value" => "",
					"description" => ""
				),
				array(
					"type" => "textarea_html",
					"admin_label" => true,
					"heading" => __("Content",'bolder'),
					"param_name" => "content",
					"value" =>'',
					'dependency' => array(
						'element' => 'choose_style_team',
						'value' => array( 'style1' )
					),
					"description" => __("Story member content",'bolder')
				),
				$add_css_style,
			)
		));

//******************************************************************************************************/
// Testimonial
//******************************************************************************************************/

		$testimonial_term = array();
		$testimonial_terms  =  get_terms("testimonials_cats");
		foreach( $testimonial_terms as $testimonial_cat ){
			$testimonial_term[$testimonial_cat->name] = $testimonial_cat->slug;

		}
		wp_reset_postdata();


		vc_map( array(
			"name" => __("Testimonial Shortcode",'bolder'),
			"base" => "bolder_testimonials",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					"admin_label" => true,
					'heading' => __( 'Categories display', 'bolder' ),
					'param_name' => 'testimonial_show_categories',
					'value' => $testimonial_term,
					"description" => __("Add categories testimonial display on page.",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Post Number",'bolder'),
					"param_name" => "number_post_testimonial",
					"value" => 3,
					"description" => __("Number post display in testimonial",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Autoplay",'bolder'),
					"param_name" => "auto_play",
					"value" => array(
						__('Yes') => 'true',
						__('No') => 'false',
					),
					"description" => __("Enter value autoplay for slide. ",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Slide speed",'bolder'),
					"param_name" => "slide_speed",
					"value" => 200,
					"description" => __("Enter slide speed value in milliseconds. ",'bolder'),
					"dependency" => array(
						'element' => 'auto_play',
						'value' => 'true'
					)
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("stop on hover",'bolder'),
					"param_name" => "stop_on_hover",
					"value" => array(
						__('No') => 'false',
						__('Yes') => 'true',
					),
					"description" => __("Stop autoplay on mouse hover. ",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Display navigation",'bolder'),
					"param_name" => "navigation",
					"value" => array(
						__('Yes') => 'true',
						__('No') => 'false',
					),
					"description" => __("Display next and prev buttons.. ",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Display pagination",'bolder'),
					"param_name" => "pagination",
					"value" => array(
						__('No') => 'false',
						__('Yes') => 'true',
					),
					"description" => __("Display pagination",'bolder')
				),
				array(
					"type" => "textfield",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" =>'',
					"description" => __("Add class name for element",'bolder')
				),
			)));
//******************************************************************************************************/
// Text Dropcap
//******************************************************************************************************/
		vc_map( array(
			"name" => __("Text Dropcap",'bolder'),
			"base" => "bolder_text_dropcap",
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style dropcap', 'bolder' ),
					'param_name' => 'choose_style_dropcap',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style1',
						__( 'Style 2', 'bolder' ) => 'style2',
					),
					'description' => __( 'Choose style for dropcap.', 'bolder' )
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("First Text",'bolder'),
					"param_name" => "first_text",
					"value" => "",
					"description" => __("First text dropcap",'bolder')
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Background color first text dropcap","bolder"),
					"param_name" => "background_color_fisttext",
					"value" => '#42454a', //Default color
					'dependency' => array(
						'element' => 'choose_style_dropcap',
						'value' => array( 'style1')
					),
					"description" => __("Background color first text dropcap","bolder")
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Color first text dropcap","bolder"),
					"param_name" => "color_fisttext",
					"value" => '#ffffff', //Default color		             
					"description" => __("Color first text dropcap","bolder")
				),
				array(
					"type" => "textarea_html",
					"holder" => "div",
					"heading" => __("Content Text",'bolder'),
					"param_name" => "content",
					"value" => "",
					"description" => __("Add content text drop cap",'bolder')
				),

			)
		));
//******************************************************************************************************/
// Coronathemes Twitter
//******************************************************************************************************/		  
		vc_map( array(
			'name' => __( 'Twitter Shortcode', 'bolder' ),
			'base' => 'bolder_twitter',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Number tweets",'bolder'),
					"param_name" => "number_tweet",
					"value" => '4',
					"description" => __("Enter number tweets for element",'bolder')
				),
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Maximun length",'bolder'),
					"param_name" => "max_length",
					"value" => '',
					"description" => __("Enter number of words for each tweet",'bolder')
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Class name",'bolder'),
					"param_name" => "el_class",
					"value" => '',
					"description" => __("Add class name for element",'bolder')
				),
			)));
//******************************************************************************************************/
// Contact form 7
//******************************************************************************************************/
		$args = array( 'post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1, 'post_status' => 'publish', 'post_parent' => null );
		$posts_array = get_posts($args );
		$cf7s = array();
		foreach($posts_array as $post) {
			$cf7s[$post->post_title] = $post->ID;
		}
		vc_map( array(
			'name' => __( 'Contact form', 'bolder' ),
			'base' => 'bolder_contact_form',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					"type" => "textfield",
					"admin_label" => true,
					"heading" => __("Title",'bolder'),
					"param_name" => "title",
					"value" => '',
					"description" => __("Title for contact form",'bolder')
				),
				array(
					"type" => "dropdown",
					"admin_label" => true,
					"heading" => __("Select contact form",'bolder'),
					"param_name" => "cf7",
					"value" => $cf7s,
					"description" => __("Select contact form 7, Incase empty dorpdown plese create contact form 7 the first",'bolder')
				),
				array(
					'type' => 'attach_image',
					'heading' => __( 'Background image', 'bolder' ),
					'param_name' => 'background_image',
					'value' => '',
					'description' => __( 'Select image from media library.', 'bolder' )
				),
			)));
//******************************************************************************************************/
// Divider Shortcode							
//******************************************************************************************************/		  
		vc_map( array(
			'name' => __( 'Divider Shortcode', 'bolder' ),
			'base' => 'bolder_divider_shortcode',
			"class" => "",
			"category" => __('For bolder theme','bolder'),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style divider', 'bolder' ),
					'param_name' => 'choose_style_divider',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style1',
						__( 'Style 2', 'bolder' ) => 'style2',
					),
					'description' => __( 'Choose style for divider.', 'bolder' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose width divider', 'bolder' ),
					'param_name' => 'width_divider',
					'value' => array(
						__( 'Full width', 'bolder' ) => '',
						__( 'Divider medium', 'bolder' ) => 'divider-md',
						__( 'Divider small', 'bolder' ) => 'divider-sm',
					),
					'description' => __( 'Choose width for divider.', 'bolder' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose Style Text or Icon', 'bolder' ),
					'param_name' => 'choose_icon_text',
					'value' => array(
						__( 'Divider text', 'bolder' ) => 'text',
						__( 'Divider icon', 'bolder' ) => 'icon',
					),
					'dependency' => array(
						'element' => 'choose_style_divider',
						'value' => array( 'style2')
					),
					'description' => __( 'Choose style for divider display .', 'bolder' )
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Text divider",'bolder'),
					"param_name" => "title_divider",
					"value" => 'Your text',
					'dependency' => array(
						'element' => 'choose_icon_text',
						'value' => array( 'text')
					),
					"description" => __("Add text for divider",'bolder')
				),
				array(
					"type" => "colorpicker",
					"holder" => "div",
					"heading" => __("Color divider","bolder"),
					"param_name" => "color_divider",
					"value" => '#ccc', //Default color
					'dependency' => array(
						'element' => 'choose_style_divider',
						'value' => array( 'style2')
					),
					"description" => __("Select color for divider","bolder")
				),
				array(
					'type' => 'textfield',
					"heading" => __("Icon divider",'bolder'),
					"param_name" => "icon_divider",
					'value' => '',
					'dependency' => array(
						'element' => 'choose_icon_text',
						'value' => array( 'icon')
					),
					'description' => __( 'Enter font icon awesome .eg: fa-facebook... . <a href="http://fortawesome.github.io/Font-Awesome/icons/">click here.</a>', 'bolder' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose divider parallel', 'bolder' ),
					'param_name' => 'divider_style',
					'value' => array(
						__( 'One divider', 'bolder' ) => '',
						__( 'Parallel lines', 'bolder' ) => 'divider-2',
					),
					'dependency' => array(
						'element' => 'choose_style_divider',
						'value' => array( 'style1')
					),
					'description' => __( 'Choose for divider.', 'bolder' )
				),
			)));



//******************************************************************************************************/
// Accordion Overwrite Visual composer
//******************************************************************************************************/
		vc_map( array(
			'name' => __( 'Bolder Tour', 'js_composer' ),
			'base' => 'vc_tour',
			'show_settings_on_create' => false,
			'is_container' => true,
			'container_not_allowed' => true,
			'icon' => 'icon-wpb-ui-tab-content-vertical',
			'category' => __( 'For bolder theme', 'js_composer' ),
			'wrapper_class' => 'vc_clearfix',
			'description' => __( 'Vertical tabbed content', 'js_composer' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Widget title', 'js_composer' ),
					'param_name' => 'title',
					'description' => __( 'Enter text used as widget title (Note: located above content element).', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Extra class name', 'js_composer' ),
					'param_name' => 'el_class',
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' )
				)
			),
			'custom_markup' => '
<div class="wpb_tabs_holder wpb_holder vc_clearfix vc_container_for_children">
<ul class="tabs_controls">
</ul>
%content%
</div>'
		,
			'default_content' => '
[vc_tab title="' . __( 'Tab 1', 'js_composer' ) . '"][/vc_tab]
[vc_tab title="' . __( 'Tab 2', 'js_composer' ) . '"][/vc_tab]
',
			'js_view' => 'VcTabsView'
		) );

		vc_map( array(
			"name" => __( 'Bolder Tabs', 'js_composer' ),
			'base' => 'vc_tabs',
			'show_settings_on_create' => false,
			'is_container' => true,
			'icon' => 'icon-wpb-ui-tab-content',
			'category' => __( 'For bolder theme', 'js_composer' ),
			'description' => __( 'Tabbed content', 'js_composer' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Widget title', 'js_composer' ),
					'param_name' => 'title',
					'description' => __( 'Enter text used as widget title (Note: located above content element).', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Extra class name', 'js_composer' ),
					'param_name' => 'el_class',
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' )
				)
			),
			'custom_markup' => '
<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
<ul class="tabs_controls">
</ul>
%content%
</div>'
		,
			'default_content' => '
[vc_tab title="' . __( 'Tab 1', 'js_composer' ) . '" ][/vc_tab]
[vc_tab title="' . __( 'Tab 2', 'js_composer' ) . '" ][/vc_tab]
',
			'js_view' =>'VcTabsView'
		) );

		$icon_params = array(
			array(
				'type' => 'checkbox',
				'param_name' => 'add_icon',
				'heading' => __( 'Add icon?', 'js_composer' ),
				'description' => __( 'Add icon next to section title.', 'js_composer' )
			),
		);
		$icon_params = array_merge( $icon_params, (array) vc_map_integrate_shortcode( 'vc_icon', 'i_', '',
			array(
				// we need only type, icon_fontawesome, icon_.., NOT color and etc
				'include_only_regex' => '/^(type|icon_\w*)/'
			), array(
				'element' => 'add_icon',
				'value' => 'true'
			)
		) );
		$params = array_merge(
			$icon_params,
			array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Title', 'bolder' ),
					'param_name' => 'title',
					'description' => __( 'Section title.', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Sub title', 'bolder' ),
					'param_name' => 'sub_title',
					'description' => __( 'Section sub title.', 'bolder' )
				),
			)
		);

		vc_map( array(
			'name' => __( 'Tab', 'js_composer' ),
			'base' => 'vc_tab',
			'allowed_container_element' => 'vc_row',
			'is_container' => true,
			'content_element' => false,
			'params' => $params,
			'js_view' => 'VcTabView'
		) );

		$portfolio_term = array();
		$portfolio_terms  =  get_terms("portfolio_cats");
		foreach( $portfolio_terms as $portfolio_cat ){
			$portfolio_term[$portfolio_cat->name] = $portfolio_cat->term_id;
		}

		//portfolio grid
		$portfolio_categs = get_terms('portfolio_cats');
		$portfolio_cats = array();
		foreach($portfolio_categs as $portfolio_categ) {
			$portfolio_cats[$portfolio_categ->name] = $portfolio_categ->term_id;
		}
		$portfolio_initial_filter = array('No Thanks!' => '') + $portfolio_cats;

		vc_map( array(
			"name" => __("Portfolio Grid", "js_composer"),
			//"icon" => get_template_directory_uri().'/images/composer/folder_picture.png',
			"base" => "bolder_portfolio_grid",
			"description" => "Masonry grid layout for portfolio items",
			"weight" => 20,
			//'front_enqueue_js' => get_template_directory_uri().'/js/custom/custom-isotope-portfolio.js',
			//"class" => "portfolio_grid_extended",
			"category" => __("For bolder theme", "bolder"),
			"params" => array(
				array(
					"type" => "textfield",
					"class" => "",
					"admin_label" => true,
					"heading" => __("Number of Items to Display", "bolder"),
					"param_name" => "number",
					"value" => 10,
					"description" => __("Set how many portfolio items would you like to include in the grid. Use '-1' to include all your items.", "bolder")
				),
				array(
					"type" => "checkbox",
					"class" => "",
					"heading" =>  __("Portfolio Categories", "bolder"),
					"param_name" => "categories",
					"value" => $portfolio_cats,
					"description" => __("Select from which categories to display projects(mandatory).", "bolder")
				),

				array(
					"type" => "dropdown",
					"heading" => __("Order By:", "bolder"),
					"param_name" => "portfolio_orderby",
					"value" => array(__("Menu order", "bolder") => 'menu_order', __("Date", "bolder") => 'date', __("Name", "bolder") => 'name', __("ID", "bolder") => 'id', __("Last Modified Date", "bolder") => 'modified', __("Random", "bolder") => 'random'),
					"description" => __("Order the projects in the grid.", "bolder")
				),

				array(
					"type" => "dropdown",
					"heading" => __("Order:", "bolder"),
					"param_name" => "portfolio_order",
					"value" => array(__("Descending", "bolder") => 'DESC', __("Ascending", "bolder") => 'ASC'),
					"description" => __("Set the direction order.", "bolder")
				),
				array(
					"type" => "dropdown",
					"heading" => __("Show filter", "bolder"),
					"param_name" => "show_filter",
					"value" => array(__("Show", "bolder") => '1', __("Hide", "bolder") => '0'),
					"description" => __("You can show/hide filter.", "bolder")
				),
				array(
					"type" => "textfield",
					"heading" => __("Keyword for All Projects Filter", "bolder"),
					"param_name" => "allword",
					"value" => "All",
					"description" => __("You can replace the default 'All' keyword for the initial filter with another one. If you want to hide it, you can do it with this CSS code: .all-projects {  display: none !important; }", "bolder"),
					"dependency" => array(
						"element" => "show_filter",
						"value" => "1"
					)
				),
				array(
					"type" => "dropdown",
					"heading" => __("'All' filter position.", "bolder"),
					"param_name" => "allbam",
					"value" => array(__("At the beginning", "bolder") => '', __("At the end", "bolder") => 'on-the-end'),
					"description" => __("Set where the 'All' filter should be displayed: at the beginning or at the end of the filter list.", "bolder"),
					"dependency" => array(
						"element" => "show_filter",
						"value" => "1"
					)
				),
				array(
					"type" => "dropdown",
					"heading" => __("Set Another Initial Filter", "bolder"),
					"param_name" => "initial_word",
					"value" => $portfolio_initial_filter,
					"description" => __("You can set the portfolio grid to display projects from a certain category, on the initial state. If you want to reorder the categories, use <a href='http://goo.gl/kCYZ0L'>this plugin</a>", "bolder"),
					"dependency" => array(
						"element" => "show_filter",
						"value" => "1"
					)
				)
			)
		) );


		//socials
		vc_map( array(
			'name' => __( 'Social icons', 'js_composer' ),
			'base' => 'bolder_social_icons',
			'category' => __( 'For bolder theme', 'js_composer' ),
			'description' => __( 'Display lists social selected', 'js_composer' ),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Choose style social', 'bolder' ),
					'param_name' => 'style',
					'value' => array(
						__( 'Style 1', 'bolder' ) => 'style1',
						__( 'Style 2', 'bolder' ) => 'style2',
					),
					'description' => __( 'Choose style for social.', 'bolder' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Twitter URL', 'js_composer' ),
					'param_name' => 'twitter_url',
					'description' => __( 'Enter a address Ex: http://www.twitter.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Facebook URL', 'js_composer' ),
					'param_name' => 'facebook_url',
					'description' => __( 'Enter a address Ex: http://www.facebook.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'LinkedIn URL', 'js_composer' ),
					'param_name' => 'linkedin_url',
					'description' => __( 'Enter a address Ex: http://www.linkedin.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Google+ URL', 'js_composer' ),
					'param_name' => 'googleplus_url',
					'description' => __( 'Enter a address Ex: http://www.plus.google.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Pinterest URL', 'js_composer' ),
					'param_name' => 'pinterest_url',
					'description' => __( 'Enter a address Ex: http://www.pinterest.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Dribbble URL', 'js_composer' ),
					'param_name' => 'dribbble_url',
					'description' => __( 'Enter a address Ex: http://www.dribbble.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Tumblr URL', 'js_composer' ),
					'param_name' => 'tumblr_url',
					'description' => __( 'Enter a address Ex: http://www.tumblr.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'SoundCloud URL', 'js_composer' ),
					'param_name' => 'soundcloud_url',
					'description' => __( 'Enter a address Ex: http://www.soundcloud.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Instagram URL', 'js_composer' ),
					'param_name' => 'instagram_url',
					'description' => __( 'Enter a address Ex: http://www.instagram.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Vimeo URL', 'js_composer' ),
					'param_name' => 'vimeo_url',
					'description' => __( 'Enter a address Ex: http://www.vimeo.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Youtube URL', 'js_composer' ),
					'param_name' => 'youtube_url',
					'description' => __( 'Enter a address Ex: http://www.youtube.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Flickr URL', 'js_composer' ),
					'param_name' => 'flickr_url',
					'description' => __( 'Enter a address Ex: http://www.flicker.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Dropbox URL', 'js_composer' ),
					'param_name' => 'dropbox_url',
					'description' => __( 'Enter a address Ex: http://www.dropbox.com/.', 'js_composer' )
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Github URL', 'js_composer' ),
					'param_name' => 'github_url',
					'description' => __( 'Enter a address Ex: http://www.github.com/.', 'js_composer' )
				),
			),
		));
	}
}
?>