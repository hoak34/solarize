<?php
/**
 * @package CoronaThemes_Shortcodes
 * @version 1.0
 */
if(!class_exists('bolder_shortcodes')):
	class bolder_shortcodes {

	}
endif;

class bolder_shortcodes_fe extends bolder_shortcodes {
	static $bolder_slider_code;
	private $counter_class = 0;
//******************************************************************************************************/
// Globals Function
//******************************************************************************************************/
	public function getExtraClass( $el_class ) {
		$output = '';
		if ( $el_class != '' ) {
			$output = " " . str_replace( ".", "", $el_class );
		}
		return $output;
	}

	public function getCSSAnimation( $css_animation,$data_wow_delay,$data_wow_duration) {
		$output = '';
		if ( $css_animation != '' ) {
			wp_enqueue_script( 'waypoints' );
			$output .= 'wow  ' . $css_animation.'"';
			$output .= 'data-wow-duration="'.$data_wow_duration.'"';
			$output .= 'data-wow-delay="'.$data_wow_delay.'"';
		}
		return $output;
	}
	public function bolder_shortcode_custom_css_class( $param_value, $prefix = '' ) {
		$css_class = preg_match( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', $param_value ) ? $prefix . preg_replace( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', '$1', $param_value ) : '';
		return $css_class;
	}

//*******************************************************Begin Shortcode****************************************************************//

//******************************************************************************************************/
// Section/ block title
//******************************************************************************************************/
	static function bolder_title( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_title', $atts ) : $atts;

		$html = $css ='';
		extract( shortcode_atts(
			array(
				'el_class'=>'',
				'css'=>'',
				//custom
				'title_primary'=>'',
				'title'=>'',
				'type'=>'simple',
				//'fontsize_title'=>'',
				//'title_color'=>'',
				//'des_color'=>'',
				'align_title'=>'text-left',
			), $atts ));
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$title = esc_attr($title);
		$title_primary = esc_attr($title_primary);
		if($title_primary){
			$has_rotate = false;
			if(strpos($title_primary, ',') !== false){
				$has_rotate = true;
			}
			$overlap_str = str_replace('{title_primary}', $title_primary, $title);
			$title = str_replace('{title_primary}', '<span'.($has_rotate ? ' class="rotate"' : '').'>'.$title_primary.'</span>', $title);
		}
		else{
			$overlap_str = $title = str_replace('{title_primary}', '', $title);
		}
		$html .='<div class="bolder-section-title '.$css_class1.' '.$align_title.'">
				<h3>'.$title.'</h3>';
		if($type == 'overlap'){
			$html .= '<span>'.$overlap_str.'</span>';
		}
		//$html .= apply_filters('the_content', $content);
		$html .='</div>';
		return $html;
	}

//******************************************************************************************************/
// Box
//******************************************************************************************************/
	static function bolder_box( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_box', $atts ) : $atts;

		$html = $css ='';
		extract( shortcode_atts(
			array(
				'el_class'=>'',
				'css'=>'',
				//custom
				'title'=>'',
				'link_text'=>'Read more',
				'link'=>'#',
			), $atts ));
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);
		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$html = '<div class="bolder-box '.$css_class1.'">';
		$html .= '<div class="bolder-box-inner">';
		$html .= '<div class="box-content">';
		$html .= '<h3>'.esc_attr($title).'</h3>';
		$html .=  apply_filters('the_content',$content);
		$html .=  '<a href="'.esc_url($link).'" title="">'.esc_attr($link_text).'</a>';
		$html .='</div>';
		$html .='</div>';
		$html .='</div>';
		return $html;
	}

//******************************************************************************************************/
// Call to action
//******************************************************************************************************/
	static function bolder_call_to_action( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_call_to_action', $atts ) : $atts;

		$html = $css ='';

		extract( shortcode_atts(
			array(
				'el_class'=>'',
				'css'=>'',
				//custom
				'bolder_cta_title'=>'',
				'bolder_cta_title'=>'',
				'color_title'=>'',
				'bolder_cta_text_link'=>'',
				'bolder_cta_url'=>'',
				'color_hover_button'=>'',
				'color_button'=>'',
				'color_border_button'=>'',
				'style_border_button'=>'',
				'width_border_button'=>'',
				'color_text_button'=>'',
				'color_text_description'=>'',
				'color_text_button_hover'=>'',

			), $atts ));
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );

		$border_button_style ='border:'.$width_border_button.'px '.$style_border_button.' '.$color_border_button.'';


		$dem_button =rand(0,1000);
		$html .='<div class="bolder-CTA">
						<div class="row">
							<div class="col-lg-7 col-md-7 col-sm-9 col-xs-12">
								<div class="bolder-left-CTA" style="color:'.esc_attr($color_text_description).';">
									<h3 style="color:'.esc_attr( $color_title).';">'.apply_filters('the_title',$bolder_cta_title).'</h3>';
		$html  .= apply_filters('the_content',$content);
		$html	.='</div>
							</div>
							<div class="col-lg-5 col-md-5 col-sm-3 col-xs-12">
								<div class="bolder-right-CTA bolder-right-CTA-'.$dem_button.'">
									<a class="bolder-style-button-cta" style="background:'.$color_button.';color:'.$color_text_button.';'.$border_button_style.'" href="'.esc_url($bolder_cta_url).'">'.$bolder_cta_text_link.'</a>
								</div>
							</div>
						</div>
					</div>
					<script>
						jQuery(document).ready(function(){
						  jQuery(".bolder-right-CTA-'.$dem_button.' a.bolder-style-button-cta").hover(function(){
						    jQuery(".bolder-right-CTA-'.$dem_button.' a.bolder-style-button-cta").css("background","'.esc_attr($color_hover_button).'");
						    jQuery(".bolder-right-CTA-'.$dem_button.' a.bolder-style-button-cta").css("color","'.esc_attr($color_text_button_hover).'");
						    },function(){
						    jQuery(".bolder-right-CTA-'.$dem_button.' a.bolder-style-button-cta").css("background","'.esc_attr($color_button).'");
						    jQuery(".bolder-right-CTA-'.$dem_button.' a.bolder-style-button-cta").css("color","'.esc_attr($color_text_button).'");
						  });
						});
					</script>';
		return $html;
	}
//******************************************************************************************************/
// Our Service
//******************************************************************************************************/
	static function bolder_service_icon( $atts , $content = null) {
		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_service_icon', $atts ) : $atts;
		$html = $css ='';

		extract( shortcode_atts(
			array(
				'el_class'=>'',
				'css'=>'',
				//custom

				'style' => '',
				//counter for style 2
				'count'=>'0',
				'count_position'=>'left',
				//icon
				'i_type'=>'fontawesome',
				'i_icon_fontawesome'=>'',
				'i_icon_openiconic'=>'',
				'i_icon_typicons'=>'',
				'i_icon_entypo'=>'',
				'i_icon_linecons'=>'',

				'content_align'=>'',
				'service_title'=>'',
				'service_url'=>'#',
				'show_readmore'=>'0',
				'readmore_text'=>'',
			), $atts ));
		$iconClass = isset( ${"i_icon_" . $i_type} ) ? esc_attr( ${"i_icon_" . $i_type} ) : 'fa fa-adjust';
		vc_icon_element_fonts_enqueue( $i_type );

		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$css_class1 .= ' service-content-'.$content_align;

		if($style == 'style-1'){
			$html .='<div class="bolder-service service-style-1 clearfix '.esc_attr($css_class1).'">';
			$html .='<div class="service-icon"><i class="'.$iconClass.'"></i></div>';
			if($show_readmore == 1){
				$html .='<h3 class="service-title">'.esc_attr($service_title).'</h3>';
			}
			else{
				$html .='<h3 class="service-title"><a href="'.esc_url($service_url).'">'.esc_attr($service_title).'</a></h3>';
			}
			$html .='<div class="service-content">'.apply_filters('the_content',$content).'</div>';
			if($show_readmore == 1){
				$html .='<a class="read-more button" href="'.esc_url($service_url).'">'.esc_attr($readmore_text).'</a>';
			}
			$html .='</div>';
		}
		elseif($style == 'style-2'){
			$html .='<div class="bolder-service service-style-2 clearfix '.esc_attr($css_class1).'">';
				$html .='<div class="row">';
					if($count_position == 'left'){
						$html .='<div class="col-md-4">';
						$html .='<div class="counting">'.$count.'</div>';
						$html .='</div>';
					}
					$html .='<div class="col-md-8">';
						$html .='<div class="service-wrap">';
							$html .='<div class="service-icon"><i class="'.$iconClass.'"></i></div>';
							if($show_readmore == 1){
								$html .='<h3 class="service-title">'.esc_attr($service_title).'</h3>';
							}
							else{
								$html .='<h3 class="service-title"><a href="'.esc_url($service_url).'">'.esc_attr($service_title).'</a></h3>';
							}
							$html .='<div class="service-content">'.apply_filters('the_content',$content).'</div>';
							if($show_readmore == 1){
								$html .='<a class="read-more button" href="'.esc_url($service_url).'">'.esc_attr($readmore_text).'</a>';
							}
						$html .='</div>';
					$html .='</div>';
					if($count_position == 'right'){
						$html .='<div class="col-md-4">';
						$html .='<div class="counting">'.$count.'</div>';
						$html .='</div>';
					}
				$html .='</div>';
			$html .='</div>';
		}

		return $html;
	}

	static function getImageSquareSize( $img_id, $img_size ) {
		if ( preg_match_all( '/(\d+)x(\d+)/', $img_size, $sizes ) ) {
			$exact_size = array(
				'width' => isset( $sizes[1][0] ) ? $sizes[1][0] : '0',
				'height' => isset( $sizes[2][0] ) ? $sizes[2][0] : '0',
			);
		} else {
			$image_downsize = image_downsize( $img_id, $img_size );
			$exact_size = array(
				'width' => $image_downsize[1],
				'height' => $image_downsize[2],
			);
		}
		if ( isset( $exact_size['width'] ) && (int) $exact_size['width'] !== (int) $exact_size['height'] ) {
			$img_size = (int) $exact_size['width'] > (int) $exact_size['height']
				? $exact_size['height'] . 'x' . $exact_size['height']
				: $exact_size['width'] . 'x' . $exact_size['width'];
		}

		return $img_size;
	}
//******************************************************************************************************/
// Pricing Table
//******************************************************************************************************/
	static function bolder_pricing_table( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_pricing_table', $atts ) : $atts;

		$html = '';
		extract( shortcode_atts(
			array(
				'css' => '',
				//custom
				'pricing_table_style'=>'',
				'pricing_title'=>'',
				'pricing_currency'=>'',
				'pricing_price'=>'',
				'pricing_unit'=>'',
				'pricing_link_button'=>'',
				'pricing_text_button'=>'',
				'class_active'=>'',
				'pricing_subtitle'=>'',
				'pricing_image'=>'',
				'pricingi_type' => 'fontawesome',
				'pricingi_icon_fontawesome'=>'',
				'pricingi_icon_openiconic'=>'',
				'pricingi_icon_typicons'=>'',
				'pricingi_icon_entypo'=>'',
				'pricingi_icon_linecons'=>'',

			), $atts ));

		// Content
		if($pricing_table_style =='style1')	{
			$html .='<div class="bolder-pricing-table-style1 '.$class_active.'">
								<div class="currency-price-unit">
									<span class="currency">'.$pricing_currency.'</span>
									<span class="price">'.$pricing_price.'</span>
									<span class="unit">'.$pricing_unit.'</span>
								</div>
								<h3>'.esc_attr($pricing_title).'</h3>';
			$html .= apply_filters('the_content',$content);
			$html .='<a class="cta_pricing" href="'.esc_url($pricing_link_button).'">'.$pricing_text_button.'</a>
							</div>';
		}elseif($pricing_table_style=='style2'){
			$html .='<div class="bolder-pricing-table-style2 '.$class_active.'">
							<h3>'.$pricing_title.'</h3>
							<div class="currency-price-unit">
								<span class="currency">'.$pricing_currency.'</span>
								<span class="price">'.$pricing_price.'</span>
								<span class="unit">'.$pricing_unit.'</span>
								</div>';
			$html .= apply_filters('the_content',$content);
			$html .='<a class="cta_pricing" href="'.esc_url($pricing_link_button).'">'.$pricing_text_button.'</a>
							</div>';
		}elseif($pricing_table_style =='style3'){
			vc_icon_element_fonts_enqueue( $pricingi_type );
			$iconClass = isset( ${"pricingi_icon_" . $pricingi_type} ) ? esc_attr( ${"pricingi_icon_" . $pricingi_type} ) : 'fa fa-adjust';

			$html .='<div class="bolder-pricing-table-style3 clearfix '.$class_active.'">';
			$html .='	<div class="pricing-table-inner"><div class="pricing-title">
							<h3>'.esc_attr($pricing_title).'</h3>';
							if($pricing_subtitle){
								$html .='<p>'.esc_attr( $pricing_subtitle).'</p>';
							}
			$html .='	</div>';
			$html .='	<div class="currency-price-unit-icon">
							<span class="pricing-icon"><i class="'.esc_attr($iconClass).'"></i></span>
							<h3 class="currency-price-unit">
								<span class="currency">'.$pricing_currency.'</span>
								<span class="price">'.$pricing_price.'</span>
								<span class="unit">'.$pricing_unit.'</span>
							</h3>
						</div>';
			$html .= apply_filters('the_content',$content);
			$html .='<div class="pricing-button">';
			if($pricing_image){
				$pricing_image = wp_get_attachment_image_src( $pricing_image, 'pricing' );
				$html .=' <img src="'.esc_url($pricing_image[0]).'" alt="" />';
			}
			$html .=' <a class="cta_pricing" href="'.esc_url($pricing_link_button).'">'.$pricing_text_button.'</a>
					</div>
							</div></div>';
		}
		return $html;
	}
//******************************************************************************************************/
// FunFact
//******************************************************************************************************/
	static function bolder_funfact( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_funfact', $atts ) : $atts;

		$html = '';

		extract( shortcode_atts(
			array(
				// alway
				'css' => '',
				//custom
				'i_type' => 'fontawesome',
				'i_icon_fontawesome'=>'',
				'i_icon_openiconic'=>'',
				'i_icon_typicons'=>'',
				'i_icon_entypo'=>'',
				'i_icon_linecons'=>'',

				'number_funfact' =>'',
				'unit_funfact' =>'',
				'speed_funfact' =>'1000',
				'add_comma' => '',
				'name_funfact' =>'',

				'custom'=>'',
				'color_icon' =>'',
				'color_text' =>'',
			), $atts ));

		vc_icon_element_fonts_enqueue( $i_type );

		$iconClass = isset( ${"i_icon_" . $i_type} ) ? esc_attr( ${"i_icon_" . $i_type} ) : 'fa fa-adjust';

		$funfact_settings = array();
		$funfact_settings['to'] = $number_funfact;
		$funfact_settings['speed'] = (int)$speed_funfact;
		$funfact_settings['add_comma'] = $add_comma ? true : false;

		$text_style = $icon_style = '';
		if($custom == 'true'){
			$text_style = 'style="color:'.esc_attr($color_text).'"';
			$icon_style = 'style="color:'.esc_attr($color_icon).'"';
		}
		$html .='<div class="bolder-funfact" '.$text_style.' data-settings="'.esc_attr(json_encode((object)$funfact_settings)).'">
							<span class="funfact-icon" '.$icon_style.'><i class="'.esc_attr($iconClass).'"></i></span>
							<div class="funfact-number-unit">
								<span data-number="'.esc_attr($number_funfact).'" class="funfact-number">'.$number_funfact.'</span>';
		if($unit_funfact !=''){
			$html .='			<span class="funfact-unit">'.$unit_funfact.'</span>';
		}
		$html .='		</div>
							<p '.$text_style.'>'.$name_funfact.'</p>
					</div>';
		return $html;
	}
//******************************************************************************************************/
// FunFact
//******************************************************************************************************/
	static function bolder_funfact_style2( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_funfact_style2', $atts ) : $atts;

		$html = '';

		extract( shortcode_atts(
			array(
				// alway
				'css' => '',
				//custom
				'custom' => '',
				'color_number' =>'',
				'color_title' =>'',
				'color_text' =>'',
				'number_funfact' =>'',
				'unit_funfact' =>'',
				'speed_funfact' =>'1000',
				'add_comma' => '',
				'name_funfact' =>'',
			), $atts ));

		$funfact_settings = array();
		$funfact_settings['to'] = $number_funfact;
		$funfact_settings['speed'] = (int)$speed_funfact;
		$funfact_settings['add_comma'] = $add_comma ? true : false;

		$text_style = $title_style = $number_style = '';
		if($custom == 'true'){
			$text_style = 'style="color:'.esc_attr($color_text).'"';
			$title_style = 'style="color:'.esc_attr($color_title).'"';
			$number_style = 'style="color:'.esc_attr($color_number).'"';
		}

		$html .='<div class="bolder-funfact bolder-funfact-style2" data-settings="'.esc_attr(json_encode((object)$funfact_settings)).'">
							<div class="funfact-number-unit" '.$number_style.'>
								<span data-number="'.esc_attr($number_funfact).'" class="funfact-number">'.$number_funfact.'</span>';
		if($unit_funfact !=''){
			$html .='			<span class="funfact-unit">'.$unit_funfact.'</span>';
		}
		$html .='		</div>
							<div class="bolder-funfact-info" '.$text_style.'>
								<h5 '.$title_style.'>'.$name_funfact.'</h5>
								'.apply_filters('the-content',$content).'
							</div>
					</div>';
		return $html;
	}
//******************************************************************************************************/
// Testimonials
//******************************************************************************************************/
	static function bolder_testimonials( $atts , $content) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_testimonials', $atts ) : $atts;

		$html = $el_class = $css_animation = '';
		extract( shortcode_atts(
			array(
				'el_class' 				 => '',
				'testimonial_show_categories' => '',
				'number_post_testimonial' => '3',
				'auto_play' => 'true',
				'slide_speed' => '200',
				'stop_on_hover' => 'false',
				'navigation'=> 'true',
				'pagination'  =>'false',
			), $atts ));

		global $post;
		// General args

		$args = array(
			'posts_per_page'=>$number_post_testimonial,
			'post_type' => 'testimonial',
			'tax_query' => array(
				array(
					'taxonomy' => 'testimonials_cats',
					'field' => 'slug',
					'terms' => $testimonial_show_categories,
				)
			)

		);
		//$bolder_testimonials =  query_posts( $args );
		$bolder_testimonials = new WP_Query( $args );

		$carousel_config = array();
		$carousel_config['autoPlay'] = $auto_play == 'true' ? true : false;
		$carousel_config['slideSpeed'] = (int)$slide_speed;
		$carousel_config['stopOnHover'] = $stop_on_hover == 'true' ? true : false;
		$carousel_config['navigation'] = $navigation == 'true' ? true : false;
		$carousel_config['pagination'] = $pagination == 'true' ? true : false;

		$html .= '';
		$html .='<div class="bolder-testimonial" data-settings="'.esc_attr(json_encode((object)$carousel_config)).'">';
		if ( $bolder_testimonials->have_posts() ) :
			while ( $bolder_testimonials->have_posts() ) : $bolder_testimonials->the_post();
				$testimonials_name = get_post_meta( $post->ID, 'bolder_testimonials_name', true );
				$testimonial_author_pos = get_post_meta( $post->ID, 'bolder_testimonials_position', true );
				$testimonials_website = get_post_meta( $post->ID, 'bolder_testimonials_website', true );
				$testimonials_image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'testimonial' );
				$html .= '<div class="bolder-item-testimonial text-center">
							<div class="client-quote">';
				if($post->post_excerpt){
					$html .= apply_filters('the_excerpt',$post->post_excerpt);
				} else {
					$html .= apply_filters('the_content',$post->post_content);
				}
				$html .='	</div>
							<div class="info-testimonial">
								<div class="client-info">
									<span class="client-name">'.$testimonials_name.'</span>
									<span class="client-position">'.$testimonial_author_pos.'</span>
								</div>
								<div class="client-avatar">
									<figure><a href="'.esc_url($testimonials_website).'"><img src="'.esc_url($testimonials_image[0]).'" alt=""></a></figure>
								</div>
							</div>
						</div>';
			endwhile;
		endif;
		wp_reset_postdata();
		$html .='</div>';

		return $html;

	}

//******************************************************************************************************/
// Client Worker
//******************************************************************************************************/
	static function bolder_client_work( $atts , $content) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_client_work', $atts ) : $atts;

		$html = '';
		extract( shortcode_atts(
				array(
					'onclick' => 'link_image',
					'custom_links' => '',
					'img_size' => 'client-work',
					'images' => '',
					'auto_play' => 'true',
					'slide_speed' => '200',
					'stop_on_hover' => 'false',
					'navigation'=> 'true',
					'pagination'  =>'false',
					'items_display'  =>'',
					'el_class' => '',
				), $atts )
		);

		$carousel_config = array();
		$carousel_config['autoPlay'] = $auto_play == 'true' ? true : false;
		$carousel_config['slideSpeed'] = (int)$slide_speed;
		$carousel_config['stopOnHover'] = $stop_on_hover == 'true' ? true : false;
		$carousel_config['navigation'] = $navigation == 'true' ? true : false;
		$carousel_config['pagination'] = $pagination == 'true' ? true : false;
		if($items_display){
			$carousel_config['itemsCustom'] = json_decode($items_display);
		}

		if ( $images == '' ) $images = '-1,-2,-3';
		if ( $onclick == 'custom_link' ) {
			$custom_links = explode( ',', $custom_links );
		}
		$images = explode( ',', $images );
		$i = - 1;
		$html .= '<ul class="bolder-client-list" data-settings="'.esc_attr(json_encode((object)$carousel_config)).'">';
		foreach ( $images as $attach_id ):
			$i++;
			if ( $attach_id > 0 ) {
				$post_thumbnail = wpb_getImageBySize( array( 'attach_id' => $attach_id, 'thumb_size' => $img_size ) );
			} else {
				$post_thumbnail = array();
				$post_thumbnail['thumbnail'] = '<figure><img src="' . vc_asset_url( 'vc/no_image.png' ) . '" /></figure>';
				$post_thumbnail['p_img_large'][0] = vc_asset_url( 'vc/no_image.png' );
			}
			$thumbnail = $post_thumbnail['thumbnail'];

			$html.= '<li class="client-item">';
			if ( $onclick == 'link_image' ){
				$p_img_large = $post_thumbnail['p_img_large'];
				$html.= '<a href="'.$p_img_large[0].'" >'.$thumbnail.'</a>';
			}
			elseif ( $onclick == 'custom_link' && isset( $custom_links[$i] ) && $custom_links[$i] != '' ){
				$html.= '<a href="'.$custom_links[$i].'" target="_blank">'.$thumbnail.'</a>';
			}
			else{
				$html.= $thumbnail ;
			}
			$html.= '</li>';
		endforeach;
		$html .= '</ul>';
		return $html;
	}
//******************************************************************************************************/
// Lasted Blog
//******************************************************************************************************/
	static function bolder_lastest_blog( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_lastest_blog', $atts ) : $atts;

		$html = '';
		extract( shortcode_atts(
				array(
					'css_class'=>'',
					'number_post'=>'5',
					'style'=>''
				), $atts )
		);
		$args = array(
			'posts_per_page' => $number_post,
			'post_type'=>'post',
			'suppress_filters' => false
		);
		$lasted_blog = get_posts( $args);

		$html .='<div class="bolder-lastest-blog">';
		foreach ($lasted_blog as $post ) {
			$blog_image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large' );
			$permalink = get_permalink($post->ID);
			$date = date("F j, Y",strtotime($post->post_date));
			$html .='<div class="blog-post '.esc_attr($style).'">';
			$html .= $blog_image ? '<div class="post-thumbnail" style="background-image: url('.esc_url($blog_image[0]).')"></div>' : '';
					if($style = 'full-with'){
						$html .= '<div class="container">';
					}
			$html .= '<article>';
			$html .=' <a href="'.esc_url($permalink ).'">'.__('Read More', 'bolder').'</a>
						'.bolder_get_post_format_icon($post).'
						<h3><a href="'.esc_url($permalink ).'">'.esc_attr($post->post_title).'</a></h3>
						<span>'.__('Posted on', 'bolder').' '.$date.'</span>';
			$html .='</article>';
			if($style = 'full-with'){
				$html .= '</div>';
			}
			$html .='</div>';
		}
		$html .='</div>';

		return $html;
	}

//******************************************************************************************************/
// Twitter slide
//******************************************************************************************************/
	static function bolder_twitter( $atts , $content = null) {
		$html = $css ='';

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_twitter', $atts ) : $atts;

		extract( shortcode_atts(
			array(
				'number_tweet'=>'',
				'css'=>'',
				//custom
				'number_twitter'=>'',
				'max_length' => ''
			), $atts ));
		$tweets = array();
		if (class_exists('TwitterOAuth')) {
			$number = intval($number_tweet);
			$tweets = getTweets($number);
		}
		$html .= '<div class="bolder-twitter-slide text-center">
				<i class="icon-twitter ti-twitter"></i>
				<div id="owl-twitter" class="twitter-slide">';
		if( $tweets){
			foreach($tweets as $tweet){
				$html .='<div class="twitter-item">';
				$text = str_replace($tweet['entities']['urls']['0']['url'] , '', $tweet['text']);
				if($max_length){
					$text = wp_trim_words($text , $max_length, '...' );
				}
				$html .='<p>'.$text.'</p>
        		<a href="'.esc_url($tweet['entities']['urls']['0']['url']).'" target="_blank">'.$tweet['entities']['urls'][0]['url'].'</a>
        		<span>'.bolder_timeAgo($tweet['created_at']).'</span>
                </div>';
			}} else {
			$html .='<div class="twitter-item">
                <p>Please install and config "oAuth Twitter Feed for Developers" plugin first! <a href="'.admin_url('plugins.php').'">Go to plugin</a></p>
                </div> ';
		}
		$html .='</div>
			</div>';


		return $html;
	}
//******************************************************************************************************/
// Dropcap
//******************************************************************************************************/
	static function bolder_text_dropcap( $atts , $content = null) {
		// Attributes

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_text_dropcap', $atts ) : $atts;

		extract( shortcode_atts(
				array(
					'choose_style_dropcap'=>'',
					'first_text' => '',
					'background_color_fisttext' => '',
					'color_fisttext' => '',
				), $atts )
		);
		if($choose_style_dropcap=='style1'){
			$html = '<span class="bolder-dropcap-'.$choose_style_dropcap.'" style="background-color:'.$background_color_fisttext.';color:'.$color_fisttext.';">'.$first_text.'</span>'.apply_filters('the_content', $content).'';
		}else{
			$html = '<span class="bolder-dropcap-'.$choose_style_dropcap.'" style="color:'.$color_fisttext.'">'.$first_text.'</span>'.apply_filters('the_content', $content).'';
		}
		return $html;
	}
//******************************************************************************************************/
// Team Member
//******************************************************************************************************/
	static function bolder_team_member( $atts , $content = null) {
		$html = $el_class = $css_animation = '';

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_team_member', $atts ) : $atts;

		extract( shortcode_atts(
			array(
				// alway
				'el_class' => '',
				'css' => '',
				//custom
				'choose_style_team'=>'',
				'bg_member'=>'',
				'fa_tiwtter'=>'',
				'fa_behance'=>'',
				'fa_dribble'=>'',
				'fa_facebook'=>'',
				'fa_youtube'=>'',
				'fa_google'=>'',
				'fa_vine'=>'',
				'fa_tumblr'=>'',
				'name_member' =>'',
				'member_postion' =>'',
			), $atts ));

		if(isset($bg_member) && is_numeric($bg_member))
		{
			$bg_member = wp_get_attachment_image_src($bg_member,'team-member');
			$bg_member = $bg_member[0];
		}

		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ' . $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		if($choose_style_team=='style1'){
			$html .='<div class="team-item team-item-'.$choose_style_team.' text-center '.$css_class1.'"><figure><img alt="" src="'.esc_url($bg_member).'">';
			$html .='<ul class="social-network list-inline social-network-team">';
			if($fa_tiwtter !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_tiwtter).'"><i class="ti-twitter"></i></a></li>';
			}
			if($fa_facebook !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_facebook).'"><i class="ti-facebook"></i></a></li>';
			}
			if($fa_youtube !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_youtube).'"><i class="ti-youtube"></i></a></li>';
			}
			if($fa_google !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_google).'"><i class="ti-google"></i></a></li>';
			}
			if($fa_behance !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_behance).'"><i class="fa fa-behance"></i></a></li>';
			}
			if($fa_dribble !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_dribble).'"><i class="ti-dribbble"></i></a></li>';
			}
			if($fa_vine !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_vine).'"><i class="fa fa-vine"></i></a></li>';
			}
			if($fa_tumblr !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_tumblr).'"><i class="ti-tumblr"></i></a></li>';
			}
			$html .='</ul>';
			$html .='</figure>';
			$html .='<h3>'.$name_member.'</h3>';
			$html .='<span>'.$member_postion.'</span>';
			$html .= apply_filters('the_content',strip_tags($content));
			$html .='</div>';
		}else{
			$html .='<div class="text-center team-item-'.$choose_style_team.'">
        			 <figure><img class="img-circle" alt="" src="'.esc_url($bg_member).'"></figure>';
			$html .='<h3>'.$name_member.'</h3>';
			$html .='<span>'.$member_postion.'</span>';
			$html .='<ul class="social-network list-inline social-network-team">';
			if($fa_tiwtter !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_tiwtter).'"><i class="fa fa-twitter"></i></a></li>';
			}
			if($fa_facebook !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_facebook).'"><i class="fa fa-facebook"></i></a></li>';
			}
			if($fa_youtube !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_youtube).'"><i class="fa fa-youtube"></i></a></li>';
			}
			if($fa_google !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_google).'"><i class="fa fa-google-plus"></i></a></li>';
			}
			if($fa_behance !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_behance).'"><i class="fa fa-behance"></i></a></li>';
			}
			if($fa_dribble !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_dribble).'"><i class="fa fa-dribbble"></i></a></li>';
			}
			if($fa_vine !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_vine).'"><i class="fa fa-vine"></i></a></li>';
			}
			if($fa_tumblr !=''){
				$html .='<li><a target="_blank" title="'.esc_attr($name_member).'" href="'.esc_url($fa_tumblr).'"><i class="fa fa-tumblr"></i></a></li>';
			}
			$html .='</ul>';
			$html .='</div>';
		}
		return $html;
	}
//******************************************************************************************************/
	/*	Skillbar Shortcode
    //******************************************************************************************************/

	static function bolder_skillbar_shortcode( $atts, $content = null ) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_skillbar_shortcode', $atts ) : $atts;

		$output = $el_class ='';

		extract( shortcode_atts( array(
			'css' => '',
			'values' => '',
			'units' => '%',
			'custom_skillbar'=>'',
			'skillbar_background_color' => '',
			'percentbar_background_color' => '',
			'skill_bar_text_color' => '',
			'skill_bar_style' => '',
			'skill_bar_title' => '',
			'skill_bar_subtitle' => '',
			'skill_bar_text_button' => '',
			'skill_bar_link_button' => '',
		), $atts ) );

		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);
		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_text_column ' . $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );

		$array_values = explode(",", $values);

		$_skillbar_style = $_skill_bar_bg_style = $_skillbar_bar_style = '';
		if($custom_skillbar){
			$_skillbar_style = 'style="color: '.$skill_bar_text_color.';"';
			$_skill_bar_bg_style = 'style="color: '.$skillbar_background_color.';"';
			$_skillbar_bar_style = 'style="color: '.$percentbar_background_color.';"';
		}
		if($skill_bar_style=='skillbarstyle1'){
			$output .= '<div class=" '.$css_class1.'">';
			$output .= '<div class="'.$skill_bar_style.'" '.$_skillbar_style.'>';
			foreach($array_values as $skill_value) {
				$data = explode("|", $skill_value);
				$output .= '<div class="skillbar clearfix " data-percent="'.$data['0'] . $units.'">
									<div class="skillbar-title"><span>'.$data['1'].'</span></div>
										<div class="skill-bar-bg" '.$_skill_bar_bg_style.'>
										<div class="skillbar-bar" '.$_skillbar_bar_style.'>
											<div class="skill-bar-percent">'.$data['0'].$units .'</div>
										</div>
									</div>
								</div>';
			}

			$output .='</div>';
			$output .='</div>';

		}elseif($skill_bar_style=='skillbarstyle2') {
			$output .= '<div class=" '.$css_class1.'">';
			$output .= '<div class="'.$skill_bar_style.'" '.$_skillbar_style.'>';
			foreach($array_values as $skill_value) {
				$data = explode("|", $skill_value);
				$output .= '<div class="skillbar clearfix " data-percent="'.$data['0'] . $units.'">
								<div class="skill-bar-bg" '.$_skill_bar_bg_style.'>
								<div class="skillbar-bar" '.$_skillbar_bar_style.'>
									<div class="skill-bar-percent"><span>'.$data['1'].'</span>('.$data['0'].$units .')</div>
								</div>
							</div>
						</div>';
			}
			$output .='</div>';
			$output .='</div>';
		}
		else{
			$output .= '<div class=" '.$css_class1.'">';
			$output .= '<div class="'.$skill_bar_style.'" '.$_skillbar_style.'>';
			foreach($array_values as $skill_value) {
				$data = explode("|", $skill_value);
				$output .= '<div class="skillbar clearfix " data-percent="'.$data['0'] . $units.'">
									<div class="skillbar-title"><span>'.$data['1'].'</span></div>
										<div class="skill-bar-bg" '.$_skill_bar_bg_style.'>
										<div class="skillbar-bar" '.$_skillbar_bar_style.'></div>
										<span class="skill-bar-percent">'.$data['0'].$units .'</span>
									</div>
								</div>';
			}
			$output .='</div>';
			$output .='</div>';
		}
		return $output;
	}

//******************************************************************************************************/
// Process bar
//******************************************************************************************************/
	static function bolder_process_bar( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_process_bar', $atts ) : $atts;

		// Attributes
		$html = '';
		extract( shortcode_atts(
			array(
				'el_class' => '',
				'css'=>'',
				'title_skill'=>'',
				'number_skill'=>'',
				'unit_skill'=>'',
				'fontsize_skill' =>'',
				'dimension_skill'=>'',
				'width_skill'=>'',
				'color_skill'=>'',
				'bgcolor_skill'=>'',
				'custom_skill'=>'',
				'color_title_skill'=>'',
				'color_text_skill'=>'',
			), $atts ));
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);
		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$dem = rand(5,1000);
		$skill_title_style = $skill_description_style = '';
		if($custom_skill == 'true'){
			$skill_title_style = 'style="color:'.$color_title_skill.'"';
			$skill_description_style = 'style="color:'.$color_text_skill.'"';
		}
		$html .='<div class="item-circles '.$css_class1.'" style="color:'.$color_title_skill.';">
                <div class="circlestat" data-dimension="'.$dimension_skill.'" data-text="'.$number_skill.$unit_skill.'" data-width="'.$width_skill.'" data-fontsize="'.$fontsize_skill.'" data-percent="'.$number_skill.'" data-fgcolor="'.$color_skill.'" data-bgcolor="'.$bgcolor_skill.'" data-fill="transparent"></div>
                <div class="process_info text-center">
                	<h5 class="skill-title" '.$skill_title_style.'>'.$title_skill.'</h5>
                	<div class="skill-description" '.$skill_description_style.'>'.apply_filters('the_content',$content).'</div>
            	</div>
            </div>';

		return $html;
	}

//******************************************************************************************************/
// CountDown
//******************************************************************************************************/
	static function bolder_countdown( $atts , $content = null) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_countdown', $atts ) : $atts;

		// Attributes
		$html = '';
		extract( shortcode_atts(
				array(
					'css'=>'',
					'el_class' => '',
					'countdown_style'=>'',
					'date_countdown'=>'',
				), $atts )
		);
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);
		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );

		$dem = rand(1,1000);


		$html .='
	<div class="bolder-countdown-'.$dem.' '.$countdown_style.' '.$css_class1.'">
	 	<div class="bolder-date-countdown bolder-day-count">
	        <span class="day-'.$dem.' date"></span>
	        <span class="month">DAY</span>
    	</div>
    	<div class="bolder-date-countdown">
	        <span class="hour-'.$dem.' date"></span>
	        <span class="month">HOURS</span>
    	</div>
    	<div class="bolder-date-countdown">
	        <span class="minute-'.$dem.' date"></span>
	        <span class="month">MINUTE</span>
    	</div>
    	<div class="bolder-date-countdown">
	        <span class="second-'.$dem.' date"></span>
	        <span class="month">SECONDS</span>
    	</div>
	 </div>';


		$countdown_ts = stripcslashes( $date_countdown);
		$items   = preg_split( '/\t\r\n|\r|\n/', $countdown_ts );
		foreach($items as $item){
			$extracts = explode("|", $item);
			$extract_date = explode("/", $extracts[0]);
			$extract_time = explode("/", $extracts[1]);
			$html .='<script type="text/javascript">
				jQuery(function($){
				 $(\'.bolder-countdown-'.$dem.'\').countdown(\''.$extract_date[0].'/'.$extract_date[1].'/'.$extract_date[2].' '.$extract_time[0].':'.$extract_time[1].':'.$extract_time[2].'\', function(event) {
			    	var bolder_day = event.strftime(\'%-D\');
			    	var bolder_hour = event.strftime(\'%-H\');
			    	var bolder_minute = event.strftime(\'%-M\');
			    	var bolder_second = event.strftime(\'%-S\');
			    	$(\'.day-'.$dem.'\').html(bolder_day);
			    	$(\'.hour-'.$dem.'\').html(bolder_hour);
			    	$(\'.minute-'.$dem.'\').html(bolder_minute);
			    	$(\'.second-'.$dem.'\').html(bolder_second);
			  });
			});
			</script>';
		}
		return $html;
	}
//******************************************************************************************************/
// style button
//******************************************************************************************************/
	static function bolder_advanced_button( $atts , $content = null) {
		// Attributes
		$html = '';

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_advanced_button', $atts ) : $atts;

		extract( shortcode_atts(
			array(
				'choose_border'=>'',
				'size_button'=>'',
				'link_button'=>'',
				'postion_button'=>'',
				'color_button'=>'',
				'color_hover_button'=>'',
				'color_text_button'=>'',
				'color_text_hover_button'=>'',
				'border_button'=>'',
				'color_border_button'=>'',
				'style_border_button'=>'solid',
				'width_border_button'=>'2',
				'border_radius'=>'',
				'border_radius_width'=>'3',
				'border_custom_css'=> '',
				'border_custom_css_hover'=> '',
			), $atts ));

		$button_style = $button_style_hover = array();
		if($color_button){
			$button_style['background'] = "background: {$color_button}";
		}
		if($color_button){
			$button_style['color'] = "color: {$color_text_button}";
		}
		if($border_button=='yes'){
			$button_style['border'] = 'border: '.$width_border_button.'px '.$style_border_button.' '.$color_border_button;
		}
		if(isset($border_radius_width)){
			$button_style['border-radius'] = "border-radius: {$border_radius_width}px";
		}
		if(strip_tags($border_custom_css)){
			$button_style['custom'] = strip_tags(preg_replace( "/\r|\n/", "", $border_custom_css ));
		}

		$button_style_hover = $button_style;
		if($color_hover_button){
			$button_style_hover['background'] = "background: {$color_hover_button}";
			if($border_button=='yes'){
				$button_style_hover['border'] = 'border:'.$width_border_button.'px '.$style_border_button.' '.$color_hover_button;
			}
		}
		if($color_text_hover_button){
			$button_style_hover['color'] = "color: {$color_text_hover_button}";
		}
		if(strip_tags($border_custom_css_hover)){
			$button_style_hover['custom_hover'] = strip_tags(preg_replace( "/\r|\n/", "", $border_custom_css_hover));
		}

		$dem_button = rand(0,1000);
		$html .='<div class="bolder-button-text bolder-button-'.$dem_button.' '. $postion_button.'">
				<a href="'.esc_url($link_button).'" class="bolder-style-button '.$size_button.'" style="'.esc_attr(implode('; ', $button_style)).'">'.$content.'</a>
			</div>
			<script>
				jQuery(document).ready(function($){
				  $(".bolder-button-'.$dem_button.' a.bolder-style-button").hover(function(){
				    $(this).attr("style","'.esc_attr(implode('; ', $button_style_hover)).'");
				  },function(){
				    $(this).attr("style","'.esc_attr(implode('; ', $button_style)).'");
				  });
				});
			</script>';
		return $html;
	}

//******************************************************************************************************/
// Blockquoctes
//******************************************************************************************************/
	static function bolder_blockquote($atts, $content = ''){

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_blockquote', $atts ) : $atts;

		$html ='';
		extract( shortcode_atts(
			array(
				'style'=>'style1',
				'color_icon'=>'',
				'name_author' => '',
			), $atts ));
		if($style=='style1'){
			$html .='<div class="blog-quote-'.$style.' blog-quote">';
			$html .= apply_filters('the_content',$content);
			$html .='   <cite>'.esc_attr($name_author).'</cite>
					 </div>';
		}else{
			$html .='<div class="blog-quote-'.$style.' blog-quote">';
			$html .= apply_filters('the_content',$content);
			$html .='   <cite>'.esc_attr($name_author).'</cite>
					 </div>';
		}
		return $html;
	}

//******************************************************************************************************/
// Contact infomation
//******************************************************************************************************/
	static function bolder_contact_infomation($atts, $content = ''){

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_contact_infomation', $atts ) : $atts;

		$html ='';
		extract( shortcode_atts(
			array(
				'css' => '',
				'el_class' => '',
				'title_contact'=>'',
				'address_contact'=>'',
				'text_email_contact' => '',
				'phone_contact'=>'',
				'fax_contact'=>'',
			), $atts ));
		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_text_column wpb_content_element ' . $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$html .='<div class="bolder-contact-infomation left '.$css_class1.'">
						<h4>'.apply_filters('the_title',$title_contact).'</h4>';
		$html .='				<p>'.esc_attr( $address_contact).'</p>';
		$html .='		<span>Email</span>: <a href="mailto:'.esc_url($text_email_contact).'">'.esc_attr($text_email_contact).'</a><br />
						<span>Phone</span>: '.esc_attr($phone_contact).'<br />
						<span>Fax</span>: '.esc_attr($fax_contact).'<br />	';
		$html .='</div>';
		return $html;
	}

//******************************************************************************************************/
// bolder_messagebox
//******************************************************************************************************/
	static function bolder_notifications( $atts , $content) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_notifications', $atts ) : $atts;

		$output = '';
		extract(shortcode_atts(array(
			'choose_style_message_box'=>'',
			'choose_style_message' => '',
			'bolder_icon_message' => '',
			'bolder_title_message' => '',
			'bolder_color_title_message' => '',
			'color_title' => '',
		), $atts));
		if($choose_style_message=='info'){
			$bolder_icon_message = '<span><i class="fa fa-info"></i></span>';
		}
		if($choose_style_message=='warning'){
			$bolder_icon_message = '<span><i class="fa fa-exclamation"></i></span>';
		}
		if($choose_style_message=='success'){
			$bolder_icon_message = '<span><i class="fa fa-check"></i></span>';
		}
		if($choose_style_message=='error'){
			$bolder_icon_message = '<span><i class="fa fa-times"></i></span>';
		}
		if($bolder_color_title_message=='yes'){
			$color_title ='bolder-combined-notifications';
		}else{
			$color_title ='bolder-message-'.$choose_style_message_box;
		}
		if($choose_style_message_box=='no_boxed'){
			$dem = rand(0,1000);
			$output .='<div id="bolder-close-box-'.$dem.'" class="bolder-message '.$choose_style_message.'">'.$bolder_icon_message.'<div class="bolder-message-content"><p>'.apply_filters('the_title',$bolder_title_message).'</p></div><span class="bolder-close" onclick="document.getElementById(\'bolder-close-box-'.$dem.'\').style.display=\'none\'"><i class="fa fa-close"></i></span></div>';
		}else{
			$dem = rand(0,1000);
			$output .='<div id="bolder-close-box-'.$dem.'" class="'.$color_title.' '.$choose_style_message.'" >
							<div class="bolder-title-boxed">'.$bolder_icon_message.'
								<div class="bolder-message-content"><p>'.apply_filters('the_title',$bolder_title_message).'</p></div>
								<span class="bolder-close" onclick="document.getElementById(\'bolder-close-box-'.$dem.'\').style.display=\'none\'"><i class="fa fa-close"></i><span>
							</div>
							<div class="bolder-content-boxed">'.apply_filters('the_content',$content).'</div>
						</div>';
		}
		return $output;

	}
//******************************************************************************************************/
	/*	MAP
    //******************************************************************************************************/
	static function isMobile() {
		return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
	}
	static function bolder_map_shortcode( $atts, $content = null ) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_map_shortcode', $atts ) : $atts;

		$output	='';
		extract( shortcode_atts( array(
			'css_basic'=>'',
			'height' => '500',
			'address' => '',
			'lat'=>'21.582668',
			'long'=>'105.807298',
			'title_map_title'=>'',
			'title_map_phone'=>'',
			'title_map_email'=>'',
			'title_map_website'=>'',
			'style'=>'light',
		), $atts ) );

		// $prepAddr = str_replace(' ','+',$address);		
		// $geocode=file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?&address='.$prepAddr.'&sensor=false');
		// $output_ge= json_decode($geocode);
		// $lat = $output_ge->results[0]->geometry->location->lat;
		// $long = $output_ge->results[0]->geometry->location->lng;
		$map_id = 'map-'.rand(10, 1000);
		$output .='';
		$output .=' <div class="map-contact">
				 	<div id="'.$map_id.'" class="map-canvas" style="height:'.(int)$height.'px;width:100%;"></div>
					</div>
				<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
				<script type="text/javascript">
					   function initialize() {
						    var map_style_light = [
						      {
						        stylers: [
						          { hue: "#fd5047" }
						        ]
						      },{
						        featureType: "road",
						        elementType: "geometry",
						        stylers: [
						          { lightness: 100 },
						          { visibility: "simplified" }
						        ]
						      },{
						        featureType: "road",
						        elementType: "labels",
						        stylers: [
						          { visibility: "off" }
						        ]
						      }
						    ];

							var map_style_dark = [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}];
						    var styledMap = new google.maps.StyledMapType(map_style_'.$style.', {name: "Styled Map"});

						    var mapCanvas = document.getElementById("'.$map_id.'");
						    var mapOptions = {
						        center: new google.maps.LatLng('.$lat.', '.$long.'),
						        zoom: 15,
						        mapTypeControlOptions: {
						          mapTypeIds: [google.maps.MapTypeId.ROADMAP, "map_style"]
						        },
						        panControl: false,
							    zoomControl: true,							    
						        scrollwheel: false,
							    navigationControl: false,
							    mapTypeControl: true,
							    scaleControl: false,
							    draggable: '.(self::isMobile() ? 'false' : 'true').',
						      };
						    var map = new google.maps.Map(mapCanvas, mapOptions);
						    map.mapTypes.set("map_style", styledMap);
						    map.setMapTypeId("map_style");


						    	var locations = [
									[\''.$title_map_title.'\', \''.$address.'\', \''.$title_map_phone.'\', \''.$title_map_email.'\', \''.$title_map_website.'\','.$lat.', '.$long.']
									        ];
											var i;
											var description;
											var telephone;
											var email;
											var web;
											var marker;
											var link;
									        for (i = 0; i < locations.length; i++) {
												if (locations[i][1] ==\'undefined\'){ description =\'\';} else { description = locations[i][1];}
												if (locations[i][2] ==\'undefined\'){ telephone =\'\';} else { telephone = locations[i][2];}
												if (locations[i][3] ==\'undefined\'){ email =\'\';} else { email = locations[i][3];}
												if (locations[i][4] ==\'undefined\'){ web =\'\';} else { web = locations[i][4];}
									            marker = new google.maps.Marker({

									                position: new google.maps.LatLng(locations[i][5], locations[i][6]),
									                map: map,
									                title: locations[i][0],
									                desc: description,
									                tel: telephone,
									                email: email,
									                web: web
									            });
									            bindInfoWindow(marker, map, locations[i][0], description, telephone, email, web);
									        }


							  	function bindInfoWindow(marker, map, title, desc, telephone, email, web) {
								    if (web.substring(0, 7) != "http://") {
								    link = "http://" + web;
								    } else {
								    link = web;
								    }
								    // iw.open(map,marker);
								      google.maps.event.addListener(marker, "click", function() {
								             var html= "<div style=\'color:#000;background-color:#fff;padding:5px;width:200px;\'><h4>"+title+"</h4><p>"+desc+"</p><i class=\'fa fa-phone\'></i> "+telephone+"<br/><i class=\'fa fa-envelope\'></i><a href=\'mailto:"+email+"\' >  "+email+"</a><br/><i class=\'fa fa-globe\'></i><a target=\'_blank\' href=\'"+link+"\'\' >  "+web+"</a></div>";
								             var iw = new google.maps.InfoWindow({content:html});
								            iw.open(map,marker);
								      });
								}
						    }
						    google.maps.event.addDomListener(window, "load", initialize);

				</script>';

		return $output;
	}
//******************************************************************************************************/
	/*	Divider
    //******************************************************************************************************/
	static function bolder_divider_shortcode( $atts , $content) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_divider_shortcode', $atts ) : $atts;

		$output = '';
		extract(shortcode_atts(array(
			'choose_style_divider'=>'',
			'choose_icon_text'=>'',
			'title_divider'=>'',
			'color_divider'=>'',
			'icon_divider'=>'',
			'width_divider'	=>'',
			'divider_style'	=>'',
			'style_divider'	=>'',
			'width_d'	=>'',
		), $atts));

		if($width_divider=='divider-md'){
			$width_d = 'divider-md';
		}elseif($width_divider=='divider-sm'){
			$width_d = 'divider-sm';
		}else{
			$width_d = '';
		}
		if($divider_style=='divider-2'){
			$style_divider = 'divider-2';
		}
		if($choose_style_divider=='style1'){
			$output .='<hr class="divider-hr '.$style_divider.' ' .$width_d.'">';
		}else {
			if($choose_icon_text=='text'){
				$output .='<div class="divider bolder-divider-'.esc_attr($choose_icon_text).' ' .$width_d.'">
							 	<div class="divider-content">
							 		<span style="color: '.esc_attr($color_divider).'">'.apply_filters('the_title',$title_divider).'</span>
							 	</div>
							</div>';
			}else{
				$output .='<div class="divider bolder-divider-'.esc_attr($choose_icon_text).' ' .$width_d.'">
							 	<div class="divider-content">
							 		<i style="color:'.esc_attr($color_divider).'" class="fa '.$icon_divider.' fa-1x"></i>
							 	</div>
							</div>';
			}
		}
		return $output;
	}


//******************************************************************************************************/
// Button
//******************************************************************************************************/
	static function bolder_simple_button($atts , $content = null){
		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'bolder_simple_button', $atts ) : $atts;
		extract( shortcode_atts(
			array(
				'css' => '',
				'el_class' => '',
				'link' => '',
				'color'=> 'accent',
				'size'=> 'normal',
			), $atts ));

		$extra_class = new bolder_shortcodes_fe();
		$el_class1 = $extra_class->getExtraClass($el_class);

		$css_class1 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class1 . $extra_class->bolder_shortcode_custom_css_class( $css, ' ' ), $atts );
		$html = '<a href="'.$link.'" class="button '.esc_attr($color.' '.$size).$css_class1.'">'.$content.'</a>';

		return $html;
	}

//******************************************************************************************************/
// vc_tour
//******************************************************************************************************/
	static function vc_tour( $atts , $content) {
		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'vc_tour', $atts ) : $atts;
		$el_class=$output = $title = $interval = $el_class = $collapsible = $active_tab = '';
		//
		extract(shortcode_atts(array(
			'title' => '',
			'el_class' => '',
			//'active_tab' => '',
		), $atts));
		$rand = rand(5,1000);
		wpb_js_remove_wpautop($content);
		global $vc_tab_atts;

		$output = '<div class="bolder-tour '.esc_attr($el_class).'">';
		$output .= wpb_widget_title(array('title' => $title, 'extraclass' => 'bolder-tour-heading'));
		if($vc_tab_atts){
			$output .= '<ul class="nav nav-tabs">';
			foreach($vc_tab_atts as $key=>$tab_atts){
				$output .= '<li '.($key == 0 ? 'class="active"' : '').'><a data-toggle="tab" href="#bolder-tour-'.($rand+$key).'">';
				if($tab_atts['add_icon'] == 'true'){
					vc_icon_element_fonts_enqueue( $tab_atts['i_type'] );
					$iconClass = isset($tab_atts["i_icon_" . $tab_atts['i_type']] ) ? esc_attr( $tab_atts["i_icon_" . $tab_atts['i_type']] ) : 'fa fa-adjust';
					$output .= '<i class="'.$iconClass.'"></i>';
				}
				if($tab_atts['sub_title']){
					$output .= '<span>'.$tab_atts['sub_title'].'</span>';
				}
				$output .= '<strong>'.($tab_atts['title'] ? $tab_atts['title'] : __("Section", "js_composer")).'</strong>';
				$output .= '</a></li>';
			}
			$output .= '</ul>';

			$output .= '<div class="tab-content">';
			foreach($vc_tab_atts as $key=>$tab_atts){
				$output .= '<div id="bolder-tour-'.($rand+$key).'" class="tab-pane fade'.($key == 0 ? ' active in' : '').'">';
				$output .= ($tab_atts['content']=='' || $tab_atts['content']==' ') ? __("Empty section. Edit page to add content here.", "js_composer") : "\n\t\t\t\t" . wpb_js_remove_wpautop($tab_atts['content']);
				$output .= '</div>';
			}
			$output .= '</div>';

			$vc_tab_atts = array();
		}
		$output .= '</div>';

		return $output;
	}

//******************************************************************************************************/
// vc_tabs
//******************************************************************************************************/
	static function vc_tabs( $atts , $content)
	{
		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'vc_tabs', $atts ) : $atts;
		$el_class=$output = $title = $interval = $el_class = $collapsible = $active_tab = '';
		//
		extract(shortcode_atts(array(
			'choose_style_accordion' => '',
			'title' => '',
			'el_class' => '',
			//'active_tab' => '',
		), $atts));

		wpb_js_remove_wpautop($content);
		global $vc_tab_atts;

		$output = '<div class="bolder-tabs '.esc_attr($el_class).'">';
		$output .= wpb_widget_title(array('title' => $title, 'extraclass' => 'bolder-tabs-heading'));
		if($vc_tab_atts){
			$output .= '<div class="bolder-tabs-content">';
			foreach($vc_tab_atts as $key=>$tab_atts){
				$output .= '<div class="bolder-tab">';
				if($tab_atts['add_icon'] == 'true' || $tab_atts['sub_title'] || $tab_atts['title'] ){
					$output .= '<div class="bolder-tab-heading">';
					if($tab_atts['add_icon'] == 'true'){
						vc_icon_element_fonts_enqueue( $tab_atts['i_type'] );
						$iconClass = isset($tab_atts["i_icon_" . $tab_atts['i_type']] ) ? esc_attr( $tab_atts["i_icon_" . $tab_atts['i_type']]) : 'fa fa-adjust';
						$output .= '<div class="bolder-tab-icon"><i class="'.$iconClass.'"></i></div>';
					}
					if($tab_atts['sub_title']){
						$output .= '<div class="bolder-tab-sub-title">'.$tab_atts['sub_title'].'</div>';
					}
					if($tab_atts['title']){
						$output .= '<div class="bolder-tab-title">'.$tab_atts['title'].'</div>';
					}
					$output .= '</div>';
				}
				$output .= '<div class="bolder-tab-content">';
				$output .= ($tab_atts['content']=='' || $tab_atts['content']==' ') ? __("Empty section. Edit page to add content here.", "js_composer") : "\n\t\t\t\t" . wpb_js_remove_wpautop($tab_atts['content']);
				$output .= '</div>';
				$output .= '</div>';
			}
			$output .= '</div>';

			$vc_tab_atts = array();

		}
		$output .= '</div>';

		return $output;
	}

//******************************************************************************************************/
// vc_tab
//******************************************************************************************************/
	static function vc_tab( $atts , $content) {

		$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'vc_tab', $atts ) : $atts;
		$atts = shortcode_atts(array(
			'el_class'=>'',
			'content'=>$content,
			'title' => '',
			'sub_title' => '',
			'add_icon'=>'',
			'i_type'=>'fontawesome',
			'i_icon_fontawesome'=>'',
			'i_icon_openiconic'=>'',
			'i_icon_typicons'=>'',
			'i_icon_entypo'=>'',
			'i_icon_linecons'=>'',
		), $atts);
		global $vc_tab_atts;
		$vc_tab_atts[] = $atts;

		/*global $bolder_accordion_content;
		$el_class=$output = $title = '';
		extract(shortcode_atts(array(
			'el_class'=>'',
			'title' => __("Section", "js_composer")
		), $atts));
		$css_class = $el_class;
		//$section_html = ''
		$bolder_accordion_section .= '<li>';
		$output .='<h3></i>'.esc_attr($title).'</h3>
							 <div class="acordion-content">';
		$output .= ($content=='' || $content==' ') ? __("Empty section. Edit page to add content here.", "js_composer") : "\n\t\t\t\t" . wpb_js_remove_wpautop($content);
		$output .= 	'</div>';
		//$bolder_accordion_html .= $output;*/

		return '';

	}


	/*-----------------------------------------------------------------------------------*/
	/*	Portfolio Grid
    /*-----------------------------------------------------------------------------------*/

	static function bolder_portfolio_grid($atts, $content = null) {
		extract(shortcode_atts(array(
			"number" => "-1",
			"categories" => "",
			"portfolio_orderby"	=> "date",
			"portfolio_order"	=> "DESC",
			"show_filter" => "1",
			"allword" => "All",
			"initial_word" => "",
			"allbam" => ""
		), $atts));

		global $post;

		//wp_enqueue_script('dt-isotope');
		//wp_enqueue_script('dt-custom-isotope-portfolio');

		//$layout = get_post_meta($post->ID,'bolder_portfolio_columns',true);
		//$navig = get_post_meta($post->ID,'bolder_portfolio_navigation',true);
		//$nav_number = get_post_meta($post->ID,'bolder_nav_number',true);


		$cats = explode(",", $categories);

		if ( post_type_exists( 'portfolio' ) ) {
			$term_list = '';

			if(!$show_filter){
				$initial_word = '';
			}else{
				$initial_word = $initial_word ?  ($initial_word_term = get_term($initial_word) ? $initial_word_term->slug : '') : '';
			}

			$output = '';
			$output .= '<div class="bolder-portfolio" data-initial-word="'.$initial_word.'">';
			if($show_filter){
				$output .= '<ul class="filters clearfix" data-option-key="filter">';
				foreach ($cats as $cat) {
					$cat_data = get_term($cat, "portfolio_cats");
					if($cat_data){
						if (function_exists('icl_t')) {
							$term_list .= '<li><a href="#filter" data-option-value=".'. $cat_data->slug .'">' . icl_t('Portfolio Category', 'Term '.$cat_data->term_id.'', $cat_data->name) . '</a></li>';
						}
						else{
							$term_list .= '<li><a href="#filter" data-option-value=".'. $cat_data->slug .'">' . $cat_data->name . '</a></li>';
						}
					}
				}

				if($allbam == "") {
					$output .= '<li class="all-projects"><a href="#filter" data-option-value="*" class="selected active">'.$allword.'</a></li>';
					$output .= $term_list;
				}
				else {
					$output .= $term_list;
					$output .= '<li class="all-projects"><a href="#filter" data-option-value="*" class="selected active">'.$allword.'</a></li>';
				}
				$output .= '</ul>';
			}

			$output .= '<div id="portfolio-wrapper">';
			$output .= '<ul class="portfolio grid isotope">';

			$args = array(
				'post_type'=>'portfolio',
				'posts_per_page' => $number,
				'term' => 'portfolio_cats',
				'orderby' => $portfolio_orderby,
				'order'   => $portfolio_order,
				'tax_query'      => array(
					array(
						'taxonomy' => 'portfolio_cats',
						'field' => 'ids',
						'terms' => $cats,
					)
				)
			);

			$my_query = new WP_Query($args);
			if( $my_query->have_posts() ) {
				while ($my_query->have_posts()) : $my_query->the_post();

					$terms = get_the_terms( get_the_ID(), 'portfolio_cats' );
					$filter_class = array();
					$terms_name = array();
					if($terms) {
						foreach ($terms as $term) {
							$filter_class[] = $term->slug;
							$terms_name[] = $term->name;
						}
					}

					$portf_type = get_post_meta($post->ID,'bolder_portfolio_type',true);
					$portf_thumbnail_size = get_post_meta($post->ID,'bolder_portfolio_thumbnail_size',true);
					$portf_image = get_post_meta($post->ID,'bolder_portfolio_image',true);
					$portf_slider = get_post_meta($post->ID,'bolder_portfolio_slider', true);
					$portf_video = get_post_meta($post->ID,'bolder_portfolio_video',true);
					$portf_soundclound = get_post_meta($post->ID,'bolder_portfolio_soundcloud',true);

					$thumb_id = get_post_thumbnail_id($post->ID);
					$alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);

					$image_url = wp_get_attachment_url($thumb_id);

					//$grid_thumbnail = $image_url;
					//$item_class = 'item-small';

					switch ($portf_thumbnail_size) {
						case 'portfolio-big':
							$grid_thumbnail = aq_resize($image_url, 762, 526, true);
							$item_class = 'item-wide';
							break;
						case 'half-horizontal':
							$grid_thumbnail = aq_resize($image_url, 762, 263, true);
							$item_class = 'item-long';
							break;
						case 'half-vertical':
							$grid_thumbnail = aq_resize($image_url, 379, 526, true);
							$item_class = 'item-high';
							break;
						//case 'portfolio-small':
						default:
							$grid_thumbnail = aq_resize($image_url, 379, 263, true);
							$item_class = 'item-small';
							break;
					}

					if($portf_type == 'video') {
						$test_link = '<a href="'. esc_url($portf_video) .'" rel="prettyPhoto[portf_gal]" title="'. __('Quick view', 'bolder') .'"><i class="ti-search"></i></a>';
					}
					else if($portf_type == 'soundcloud') {
						$portf_image_url = $portf_image ? $portf_image : wp_get_attachment_url($thumb_id);
						$test_link = '<a href="'. esc_url($portf_image_url) .'" rel="prettyPhoto[portf_gal]" title="'. get_the_title() .'"><i class="ti-search"></i></a>';
						//$test_link = '<a href="'. esc_url($portf_soundclound) .'" rel="prettyPhoto[portf_gal]" title="'.  __('Quick view', 'bolder') .'"><i class="ti-search"></i></a>';
					}
					else if ($portf_type == 'slider') {
						$slider_output = '';
						if(!empty($portf_slider)) {
							foreach($portf_slider as $slider_item=>$slider_item_url) {
								$slider_output .= '<a class="hidden_image" href="'.esc_url($slider_item_url).'" rel="prettyPhoto[gallery_'.$post->ID.']" title="'. __('Quick view', 'bolder').'"><i class="ti-search"></i></a>';
							}
						}

						$test_link = '<a href="'. wp_get_attachment_url($thumb_id) .'" rel="prettyPhoto[gallery_'.$post->ID.']" title="'.  __('Quick view', 'bolder') .'" ><i class="ti-search"></i></a>' . $slider_output;
					}
					else{
						$portf_image_url = $portf_image ? $portf_image : wp_get_attachment_url($thumb_id);
						$test_link = '<a href="'. esc_url($portf_image_url) .'" rel="prettyPhoto[portf_gal]" title="'. get_the_title() .'"><i class="ti-search"></i></a>';
					}

					$output .= '<li class="grid-item '.implode(" ", $filter_class).' '.$item_class.'">';
					$output .= '<div class="item-wrap">';
					$output .= '<img src="'. esc_url($grid_thumbnail).'" alt="'.esc_attr($alt).'" />';
					$output .= '<h3 class="portfolio-title">'.get_the_title().'</h3>';
					//$output .= '<span class="portfolio-categories">'.implode(",", $terms_name).'</span>';
					$output .= '<ul>';
					$output .= '<li><a href="'.get_the_permalink().'" title="'.__('Details', 'bolder').'"><i class="ti-link"></i></a></li>';
					$output .= '<li>'.$test_link.'</li>';
					$output .= '</ul>';

					$output .= $test_link;
					$output .= '</div>';
					$output .= '</li>';
				endwhile;
			}
			wp_reset_postdata();
			$output .= '</ul>';
			$output .= '</div>';
			$output .= '</div>';

			return $output;
		}
	}

	/*-----------------------------------------------------------------------------------*/
	/*	Portfolio Grid
    /*-----------------------------------------------------------------------------------*/

	static function bolder_social_icons($atts, $content = null)
	{
		extract(shortcode_atts(array(
			"style"=>'style1',
			"twitter_url" => "",
			"facebook_url" => "",
			"linkedin_url" => "",
			"googleplus_url" => "",
			"pinterest_url" => "",
			"dribbble_url" => "",
			"tumblr_url" => "",
			"soundcloud_url" => "",
			"instagram_url" => "",
			"vimeo_url" => "",
			"youtube_url" => "",
			"flickr_url" => "",
			"dropbox_url" => "",
			"github_url" => "",
		), $atts));

		$html = '';
		if($twitter_url || $facebook_url || $linkedin_url || $googleplus_url || $pinterest_url || $dribbble_url || $tumblr_url ||$soundcloud_url ||
			$instagram_url || $vimeo_url || $youtube_url || $flickr_url || $dropbox_url || $github_url){
			if($style == 'style1'){
				$html .= '<ul class="social-icons-style-1">';
				if($instagram_url){
					$html .= '<li class="instagram"><a href="'.esc_attr($instagram_url).'" title=""><i class="ti-instagram"></i></a></li>';
				}
				if($dribbble_url){
					$html .= '<li class="dribbble"><a href="'.esc_attr($dribbble_url).'" title=""><i class="ti-dribbble"></i></a></li>';
				}
				if($tumblr_url){
					$html .= '<li class="tumblr"><a href="'.esc_attr($tumblr_url).'" title=""><i class="ti-tumblr"></i></a></li>';
				}
				if($youtube_url){
					$html .= '<li class="youtube"><a href="'.esc_attr($youtube_url).'" title=""><i class="ti-youtube"></i></a></li>';
				}
				if($soundcloud_url){
					$html .= '<li class="soundcloud"><a href="'.esc_attr($soundcloud_url).'" title=""><i class="ti-soundcloud"></i></a></li>';
				}
				if($twitter_url){
					$html .= '<li class="twitter"><a href="'.esc_attr($twitter_url).'" title=""><i class="ti-twitter"></i></a></li>';
				}
				if($facebook_url){
					$html .= '<li class="facebook"><a href="'.esc_attr($facebook_url).'" title=""><i class="ti-facebook"></i></a></li>';
				}
				if($linkedin_url){
					$html .= '<li class="linkedin"><a href="'.esc_attr($linkedin_url).'" title=""><i class="ti-linkedin"></i></a></li>';
				}
				if($googleplus_url){
					$html .= '<li class="googleplus"><a href="'.esc_attr($googleplus_url).'" title=""><i class="ti-google"></i></a></li>';
				}
				if($pinterest_url){
					$html .= '<li class="pinterest"><a href="'.esc_attr($pinterest_url).'" title=""><i class="ti-pinterest"></i></a></li>';
				}
				if($github_url){
					$html .= '<li class="github"><a href="'.esc_attr($github_url).'" title=""><i class="ti-github"></i></a></li>';
				}
				if($vimeo_url){
					$html .= '<li class="vimeo"><a href="'.esc_attr($vimeo_url).'" title=""><i class="ti-vimeo"></i></a></li>';
				}
				if($flickr_url){
					$html .= '<li class="flickr"><a href="'.esc_attr($flickr_url).'" title=""><i class="ti-flickr"></i></a></li>';
				}
				if($dropbox_url){
					$html .= '<li class="dropbox"><a href="'.esc_attr($dropbox_url).'" title=""><i class="ti-dropbox"></i></a></li>';
				}

				$html .= '</ul>';
			}
			elseif($style == 'style2'){
				$html .= '<ul class="social-icons-style-2 clearfix">';
				if($instagram_url){
					$html .= '<li class="instagram"><a href="'.esc_attr($instagram_url).'" title=""><i class="ti-instagram"></i>'.__('Instagram', 'bolder').'</a></li>';
				}
				if($dribbble_url){
					$html .= '<li class="dribbble"><a href="'.esc_attr($dribbble_url).'" title=""><i class="ti-dribbble"></i>'.__('Dribbble', 'bolder').'</a></li>';
				}
				if($tumblr_url){
					$html .= '<li class="tumblr"><a href="'.esc_attr($tumblr_url).'" title=""><i class="ti-tumblr"></i>'.__('Tumblr', 'bolder').'</a></li>';
				}
				if($youtube_url){
					$html .= '<li class="youtube"><a href="'.esc_attr($youtube_url).'" title=""><i class="ti-youtube"></i>'.__('Youtube', 'bolder').'</a></li>';
				}
				if($soundcloud_url){
					$html .= '<li class="soundcloud"><a href="'.esc_attr($soundcloud_url).'" title=""><i class="ti-soundcloud"></i>'.__('Soundcoud', 'bolder').'</a></li>';
				}
				if($twitter_url){
					$html .= '<li class="twitter"><a href="'.esc_attr($twitter_url).'" title=""><i class="ti-twitter"></i>'.__('Twitter', 'bolder').'</a></li>';
				}
				if($facebook_url){
					$html .= '<li class="facebook"><a href="'.esc_attr($facebook_url).'" title=""><i class="ti-facebook"></i>'.__('Facebook', 'bolder').'</a></li>';
				}
				if($linkedin_url){
					$html .= '<li class="linkedin"><a href="'.esc_attr($linkedin_url).'" title=""><i class="ti-linkedin"></i>'.__('Linkedin', 'bolder').'</a></li>';
				}
				if($googleplus_url){
					$html .= '<li class="googleplus"><a href="'.esc_attr($googleplus_url).'" title=""><i class="ti-google"></i>'.__('GooglePlus', 'bolder').'</a></li>';
				}
				if($pinterest_url){
					$html .= '<li class="pinterest"><a href="'.esc_attr($pinterest_url).'" title=""><i class="ti-pinterest"></i>'.__('Pinterest', 'bolder').'</a></li>';
				}
				if($github_url){
					$html .= '<li class="github"><a href="'.esc_attr($github_url).'" title=""><i class="ti-github"></i>'.__('Github', 'bolder').'</a></li>';
				}
				if($vimeo_url){
					$html .= '<li class="vimeo"><a href="'.esc_attr($vimeo_url).'" title=""><i class="ti-vimeo"></i>'.__('Vimeo', 'bolder').'</a></li>';
				}
				if($flickr_url){
					$html .= '<li class="flickr"><a href="'.esc_attr($flickr_url).'" title=""><i class="ti-flickr"></i>'.__('Flickr', 'bolder').'</a></li>';
				}
				if($dropbox_url){
					$html .= '<li class="dropbox"><a href="'.esc_attr($dropbox_url).'" title=""><i class="ti-dropbox"></i>'.__('Dropbox', 'bolder').'</a></li>';
				}

				$html .= '</ul>';
			}
		}

		return $html;
	}


	/*-----------------------------------------------------------------------------------*/
	/*	Contact form
    /*-----------------------------------------------------------------------------------*/

	static function bolder_contact_form($atts, $content = null)
	{
		extract(shortcode_atts(array(
			"title" => "",
			"cf7" => "",
			"background_image" => "",
		), $atts));

		$html = '<div class="bolder-contact-from clearfix">';
		$html .= '<div class="form-wrap">';
		$html .= '<h3>'.esc_attr($title).'</h3>';
		$html .= do_shortcode('[contact-form-7 id="'.$cf7.'"]');
		$html .= '<div class="image-shadow">';
		$image_url = wp_get_attachment_url($background_image);
		$image_url = aq_resize($image_url, 750, 210, true);
		$html .= '<img src="'.esc_url($image_url).'" alt="">';
		$html .= '</div>';
		$html .= '</div>';
		$html .= '</div>';

		return $html;
	}
//*********************************************End Shortcode ****************************************************************************//
}
/*My shortcodes */
add_shortcode( 'bolder_title', array('bolder_shortcodes_fe','bolder_title') );
add_shortcode( 'bolder_box', array('bolder_shortcodes_fe','bolder_box') );
add_shortcode( 'title_primary', array('bolder_shortcodes_fe','title_primary') );
add_shortcode( 'bolder_call_to_action', array('bolder_shortcodes_fe','bolder_call_to_action') );
add_shortcode( 'bolder_pricing_table', array('bolder_shortcodes_fe','bolder_pricing_table') );
add_shortcode( 'bolder_funfact', array('bolder_shortcodes_fe','bolder_funfact') );
add_shortcode( 'bolder_funfact_style2', array('bolder_shortcodes_fe','bolder_funfact_style2') );
add_shortcode( 'bolder_testimonials', array('bolder_shortcodes_fe','bolder_testimonials') );
add_shortcode( 'bolder_client_work', array('bolder_shortcodes_fe','bolder_client_work') );
add_shortcode( 'bolder_lastest_blog', array('bolder_shortcodes_fe','bolder_lastest_blog') );
add_shortcode( 'bolder_service_icon', array('bolder_shortcodes_fe','bolder_service_icon') );
add_shortcode( 'bolder_twitter', array('bolder_shortcodes_fe','bolder_twitter') );
add_shortcode( 'bolder_text_dropcap', array('bolder_shortcodes_fe','bolder_text_dropcap') );
add_shortcode( 'bolder_team_member', array('bolder_shortcodes_fe','bolder_team_member') );
add_shortcode( 'bolder_skillbar_shortcode', array('bolder_shortcodes_fe','bolder_skillbar_shortcode') );
add_shortcode( 'bolder_process_bar', array('bolder_shortcodes_fe','bolder_process_bar') );
add_shortcode( 'bolder_countdown', array('bolder_shortcodes_fe','bolder_countdown') );
add_shortcode( 'bolder_simple_button', array('bolder_shortcodes_fe','bolder_simple_button'));
add_shortcode( 'bolder_advanced_button', array('bolder_shortcodes_fe','bolder_advanced_button') );
add_shortcode( 'bolder_blockquote', array('bolder_shortcodes_fe','bolder_blockquote') );
add_shortcode( 'bolder_contact_infomation', array('bolder_shortcodes_fe','bolder_contact_infomation') );
add_shortcode( 'bolder_notifications', array('bolder_shortcodes_fe','bolder_notifications') );
add_shortcode( 'bolder_map_shortcode', array('bolder_shortcodes_fe','bolder_map_shortcode'));
add_shortcode( 'bolder_divider_shortcode', array('bolder_shortcodes_fe','bolder_divider_shortcode'));
add_shortcode( 'vc_tour', array('bolder_shortcodes_fe','vc_tour') );
add_shortcode( 'vc_tabs', array('bolder_shortcodes_fe','vc_tabs') );
add_shortcode( 'vc_tab', array('bolder_shortcodes_fe','vc_tab') );
add_shortcode( 'bolder_portfolio_grid', array('bolder_shortcodes_fe','bolder_portfolio_grid') );
add_shortcode( 'bolder_social_icons', array('bolder_shortcodes_fe','bolder_social_icons') );
add_shortcode( 'bolder_contact_form', array('bolder_shortcodes_fe','bolder_contact_form') );