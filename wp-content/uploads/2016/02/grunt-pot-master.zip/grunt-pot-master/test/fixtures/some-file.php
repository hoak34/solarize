<?php

echo gettext("I'm a translatable string.");

?>
